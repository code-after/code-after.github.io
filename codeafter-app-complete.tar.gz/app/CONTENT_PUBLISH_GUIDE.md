# Code After 内容发布指南

## 概述

发布新内容需要修改 4 个文件。以下以实际发布的 **AI Has Ancestors** 系列为例说明。

---

## 发布前准备

### 1. 内容文件

将 `.md` 文件放入 `src/data/content/` 下合适的子目录：

```
src/data/content/
  AI_has_ancestors_series/
    00-Reference.md
    01-Part One --- The Pre-Code World.md
    02-Part Two --- The Post-Code Break.md
    03-Part Three --- The Substance.md   (未发布，文件保留)
```

**图片处理**：
- 图片放入 `src/data/content/images/`
- markdown 中引用格式：`![描述](../images/xxx.png)`
- 引用的图片文件必须实际存在，否则页面显示空白

---

## 需要修改的 4 个文件

### 文件 1：tree.ts --- 菜单树和路由

**路径**：`src/data/tree.ts`

**作用**：定义左侧菜单结构 + 路由映射（path <-> id）。

**实际修改** --- 添加 AI Has Ancestors folder 和子项：

```typescript
// 在 documentTree 中，"projects" folder 的 children 里添加：
{
  id: 'ai-ancestors',
  label: 'AI Has Ancestors',
  path: '',
  type: 'folder',
  children: [
    { id: 'ai-anc-ref', label: 'Reference', path: '/ai-ancestors/reference', type: 'file' },
    { id: 'ai-anc-p1', label: 'Part One --- The Pre-Code World', path: '/ai-ancestors/part-one', type: 'file' },
    { id: 'ai-anc-p2', label: 'Part Two --- The Post-Code Break', path: '/ai-ancestors/part-two', type: 'file' },
    // Part Three 暂不发布，不放 children
  ],
},
```

**同时更新两个映射表**（文件末尾）：

```typescript
// pathToIdMap --- path 映射到 id
'/ai-ancestors/reference': 'ai-anc-ref',
'/ai-ancestors/part-one': 'ai-anc-p1',
'/ai-ancestors/part-two': 'ai-anc-p2',

// idToPathMap --- id 映射到 path
'ai-anc-ref': '/ai-ancestors/reference',
'ai-anc-p1': '/ai-ancestors/part-one',
'ai-anc-p2': '/ai-ancestors/part-two',
```

**规则**：
- `id` 全局唯一，不能重复
- `path` 以 `/` 开头，如 `/ai-ancestors/reference`
- folder 的 `path` 为空字符串 `''`，子项放在 `children` 数组中
- 不发布的页面不放 `children`，但映射表可保留（链接存在但菜单不显示）

---

### 文件 2：meta.ts --- 章节元数据

**路径**：`src/data/meta.ts`

**作用**：定义每个页面的标题、副标题、日期、标签等信息。

**实际修改** --- 在 `chapters` 对象中添加 3 条：

```typescript
'ai-anc-ref': {
  id: 'ai-anc-ref',
  title: 'AI Has Ancestors Reference',
  subtitle: 'Parts One, Two & Three',
  breadcrumb: 'AI Has Ancestors > Reference',
  date: 'June 2026',
  tags: ['ai-ancestors', 'reference'],
  file: 'content/AI_has_ancestors_series/00-Reference.md',
},
'ai-anc-p1': {
  id: 'ai-anc-p1',
  title: 'Part One --- The Pre-Code World',
  subtitle: 'The four encoding technologies that came before artificial intelligence',
  breadcrumb: 'AI Has Ancestors > Part One',
  date: 'June 2026',
  tags: ['ai-ancestors', 'pre-code', 'writing', 'alphabet'],
  file: 'content/AI_has_ancestors_series/01-Part One --- The Pre-Code World.md',
},
'ai-anc-p2': {
  id: 'ai-anc-p2',
  title: 'Part Two --- The Post-Code Break',
  subtitle: 'The fifth member crosses the line the first four never touched',
  breadcrumb: 'AI Has Ancestors > Part Two',
  date: 'June 2026',
  tags: ['ai-ancestors', 'post-code', 'tokeniser', 'chinese'],
  file: 'content/AI_has_ancestors_series/02-Part Two --- The Post-Code Break.md',
},
```

**规则**：
- `id` 必须与 `tree.ts` 中定义的一致
- `file` 路径从 `content/` 开始，如 `content/AI_has_ancestors_series/00-Reference.md`
- 日期格式：`Month YYYY`
- Part Three 不发布，不放 meta（或放 meta 但不在 tree 的 children 中显示）

---

### 文件 3：graph.ts --- 交互图节点

**路径**：`src/data/graph.ts`

**作用**：定义右侧 Interactive Graph 中的节点和边。

**实际修改** --- 添加颜色组 + 节点 + 边：

```typescript
// 1. GROUP_COLORS 中添加分组颜色
'ai-ancestors': '#4a7c59',

// 2. graphNodes 中添加节点
{ id: 'ai-anc-ref', label: 'AI Ancestors', x: 50, y: 150, radius: 7, group: 'ai-ancestors' },
{ id: 'ai-anc-p1', label: 'Pre-Code World', x: 30, y: 180, radius: 6, group: 'ai-ancestors' },
{ id: 'ai-anc-p2', label: 'Post-Code Break', x: 70, y: 180, radius: 6, group: 'ai-ancestors' },

// 3. graphEdges 中添加边
{ source: 'home', target: 'ai-anc-ref' },          // 首页连接到参考
{ source: 'ai-anc-ref', target: 'ai-anc-p1' },     // 参考 -> Part One
{ source: 'ai-anc-p1', target: 'ai-anc-p2' },      // Part One -> Part Two
{ source: 'ai-anc-p2', target: 'chapter-1' },      // Part Two 与已有内容关联
{ source: 'ai-anc-ref', target: 'overview' },      // 参考与 Overview 关联
```

**规则**：
- `id` 与 tree.ts 一致
- `x, y` 在 280x290 画布范围内
- `radius` 控制节点大小（4=小，8=大）
- 边定义节点间的语义关联，只添加 id 已存在的节点

---

### 文件 4：图片文件（如有）

**路径**：`src/data/content/images/`

**实际处理**：

Part Two 引用了 2 张图片：

```markdown
<!-- 02-Part Two --- The Post-Code Break.md 中的引用 -->
![The Token Tax --- tokens needed to encode the same passage, set against English.](../images/the_token_tax.png)
![From One Head to Two --- every earlier round ran to a single centre; the AI round has two, and the rest beneath them.](../images/from_one_head_to_two.png)
```

对应文件：
```
src/data/content/images/the_token_tax.png      (从 GitHub 仓库下载)
src/data/content/images/from_one_head_to_two.png (用户上传)
```

**检查方法**：构建后查看 dist/assets/ 目录是否包含对应图片文件。

---

## 构建部署

```bash
cd /path/to/app
npm run build
```

构建成功后，`dist/` 目录即为可部署文件。检查构建输出中的图片：

```
dist/assets/the_token_tax-xxx.png       # 确认图片被正确打包
dist/assets/from_one_head_to_two-xxx.png
dist/assets/what_each_member_took-xxx.png   # Part Three 用，暂不参与打包
```

---

## 不发布 Part Three 的处理方式

文件保留在目录中，但从以下位置移除：

1. **tree.ts**：`children` 中不添加 Part Three
2. **meta.ts**：可以保留 meta，也可以移除
3. **graph.ts**：不添加 Part Three 的节点和边

后续发布时，只需在 tree.ts children 中添加一项即可。

---

## 检查清单

发布前确认：

- [ ] `.md` 文件放入 `content/` 子目录
- [ ] 引用的图片文件已放入 `content/images/`
- [ ] `tree.ts`：菜单项已添加 + 两个映射表已更新
- [ ] `meta.ts`：章节元数据已添加
- [ ] `graph.ts`：节点和边已添加（可选，不添加则不在图中显示）
- [ ] `npm run build` 构建成功，图片出现在 `dist/assets/`
