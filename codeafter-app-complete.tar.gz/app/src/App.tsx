import { useState, useRef, useEffect, useCallback } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Menu } from 'lucide-react';
import TopBar from './components/TopBar';
import Sidebar from './components/Sidebar';
import Content from './components/Content';
import RightPanel from './components/RightPanel';
import { pathToIdMap } from './data/tree';

function AppInner() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobile, setIsMobile] = useState(false);
  const [darkMode, setDarkMode] = useState(() => {
    // Check localStorage first, then fall back to system preference
    const stored = localStorage.getItem('dark-mode');
    if (stored !== null) return stored === 'true';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const location = useLocation();
  const contentRef = useRef<HTMLDivElement>(null);

  const activeNodeId = pathToIdMap[location.pathname] || 'home';

  // Detect mobile screen and right panel visibility
  const [showRightPanel, setShowRightPanel] = useState(true);

  // Responsive sidebar width: shrinks when page narrows, caps at 420px when wide
  const [sidebarWidth, setSidebarWidth] = useState(420);

  useEffect(() => {
    const checkLayout = () => {
      const w = window.innerWidth;
      setIsMobile(w < 768);
      if (w < 768) {
        setSidebarOpen(false);
      } else {
        setSidebarOpen(true);
      }
      // Hide right panel when screen too narrow for 3-column layout
      setShowRightPanel(w >= 1300);
      // Desktop sidebar width shrinks proportionally
      if (w >= 768) {
        setSidebarWidth(Math.min(420, Math.max(340, Math.round(w * 0.32))));
      }
    };
    checkLayout();
    window.addEventListener('resize', checkLayout);
    return () => window.removeEventListener('resize', checkLayout);
  }, []);

  // Apply dark mode class to document and persist to localStorage
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('dark-mode', String(darkMode));
  }, [darkMode]);

  // Close sidebar on route change (mobile)
  useEffect(() => {
    if (isMobile) {
      setSidebarOpen(false);
    }
  }, [location.pathname, isMobile]);

  // Keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement;
        searchInput?.focus();
      }
      if (e.key === 'Escape') {
        setSidebarOpen(false);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const handleSearchChange = useCallback((query: string) => {
    setSearchQuery(query);
  }, []);

  return (
    <div style={{ height: '100vh', overflow: 'hidden' }}>
      {/* TopBar: 只在手机模式显示 */}
      {isMobile && (
        <TopBar
          sidebarOpen={sidebarOpen}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode(!darkMode)}
        />
      )}

      {/* Mobile overlay — visual only, click passes through to content */}
      {isMobile && sidebarOpen && (
        <div
          style={{
            position: 'fixed',
            top: 48,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.3)',
            zIndex: 60,
            pointerEvents: 'none',
          }}
        />
      )}

      <Sidebar
        open={sidebarOpen}
        searchQuery={searchQuery}
        onSearchChange={handleSearchChange}
        isMobile={isMobile}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        sidebarWidth={sidebarWidth}
      />

      <main
        style={{
          position: 'fixed',
          top: isMobile ? 48 : 0,
          left: isMobile ? 0 : (sidebarOpen ? sidebarWidth : 0),
          right: isMobile ? 0 : 0,
          bottom: 0,
          transition: 'left 300ms ease-in-out, right 300ms ease-in-out, background-color 200ms',
          backgroundColor: 'var(--ca-bg)',
          overflow: 'hidden',
        }}
      >
        <Content isMobile={isMobile} contentRef={contentRef} showFooter={!showRightPanel} />
      </main>

      {!isMobile && showRightPanel && <RightPanel activeNodeId={activeNodeId} contentRef={contentRef} />}

      {/* Desktop sidebar toggle button (when collapsed) */}
      {!isMobile && !sidebarOpen && (
        <button
          onClick={() => setSidebarOpen(true)}
          style={{
            position: 'fixed',
            top: 12,
            left: 12,
            zIndex: 60,
            width: 32,
            height: 32,
            borderRadius: 6,
            border: '1px solid var(--ca-border)',
            backgroundColor: 'var(--ca-bg-sidebar)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--ca-icon)',
            transition: 'color 200ms, background 200ms',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--ca-text)';
            e.currentTarget.style.backgroundColor = 'var(--ca-hover-bg)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--ca-icon)';
            e.currentTarget.style.backgroundColor = 'var(--ca-bg-sidebar)';
          }}
          title="Open sidebar"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
        </button>
      )}

      {/* Mobile floating menu button */}
      {isMobile && !sidebarOpen && (
        <button
          onClick={() => setSidebarOpen(true)}
          style={{
            position: 'fixed',
            bottom: 20,
            left: 20,
            width: 48,
            height: 48,
            borderRadius: '50%',
            backgroundColor: 'var(--ca-text)',
            color: 'var(--ca-bg)',
            border: 'none',
            boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            zIndex: 100,
          }}
        >
          <Menu size={20} />
        </button>
      )}
    </div>
  );
}

export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="*" element={<AppInner />} />
      </Routes>
    </HashRouter>
  );
}
