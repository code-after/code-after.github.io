export interface ChapterMeta {
  id: string;
  title: string;
  subtitle?: string;
  breadcrumb: string;
  date: string;
  tags: string[];
  file: string;
}

export const chapters: Record<string, ChapterMeta> = {
  'home': {
    id: 'home',
    title: 'Welcome to Code After',
    subtitle: 'A Translation Project for the AI Era',
    breadcrumb: 'Home',
    date: '',
    tags: [],
    file: 'content/home.md',
  },
  'toc': {
    id: 'toc',
    title: 'Table of Contents',
    breadcrumb: 'Contents',
    date: 'April 12, 2026',
    tags: ['contents'],
    file: 'content/v0.9/toc.md',
  },
  'front-matter': {
    id: 'front-matter',
    title: 'Front Matter',
    subtitle: 'Cover, Copyright, Abstract, Suggested Citation',
    breadcrumb: 'Front Matter',
    date: 'April 12, 2026',
    tags: ['front-matter', 'metadata'],
    file: 'content/v0.9/front-matter.md',
  },
  'preface': {
    id: 'preface',
    title: 'Preface',
    subtitle: 'Why This Book Exists',
    breadcrumb: 'Preface',
    date: 'April 12, 2026',
    tags: ['preface', 'introduction'],
    file: 'content/v0.9/preface.md',
  },
  'chapter-1': {
    id: 'chapter-1',
    title: 'Ch.1 — The World States Cannot See',
    subtitle: 'The Visibility Gap: Why Sovereignty Loses Sight',
    breadcrumb: 'Part I > Chapter 1',
    date: 'April 12, 2026',
    tags: ['visibility-gap', 'technical-opacity', 'jurisdictional-fragmentation'],
    file: 'content/v0.9/chapter-1.md',
  },
  'chapter-2': {
    id: 'chapter-2',
    title: 'Ch.2 — The Rule-Execution Gap',
    subtitle: 'Why Governance Fails at Implementation, Not Legislation',
    breadcrumb: 'Part I > Chapter 2',
    date: 'April 12, 2026',
    tags: ['rule-execution', 'fairness-trap', 'compliance-gridlock'],
    file: 'content/v0.9/chapter-2.md',
  },
  'law': {
    id: 'law',
    title: 'Sec.I — Law as the Language of Power',
    subtitle: 'The First Function: Naming What Exists',
    breadcrumb: 'Part II > Section I',
    date: 'April 12, 2026',
    tags: ['law', 'permission-framework', 'categorical-gap'],
    file: 'content/v0.9/law.md',
  },
  'accounting': {
    id: 'accounting',
    title: 'Sec.II — Accounting as the Language of Measurement',
    subtitle: 'The Rise of the Value Intermediaries',
    breadcrumb: 'Part II > Section II',
    date: 'April 12, 2026',
    tags: ['accounting', 'measurement-gap', 'value-creation'],
    file: 'content/v0.9/accounting.md',
  },
  'part-3': {
    id: 'part-3',
    title: 'Part III — The Architecture of the Global AI Stack',
    subtitle: 'From Hardware to Governance: The Vertical Integration of Power',
    breadcrumb: 'Part III',
    date: 'April 12, 2026',
    tags: ['ai-stack', 'vertical-integration', 'g3-fracture'],
    file: 'content/v0.9/part-3.md',
  },
  'part-4': {
    id: 'part-4',
    title: 'Part IV — The Governance Engine',
    subtitle: 'Design, Propagation, and the Incorporation Heuristic',
    breadcrumb: 'Part IV',
    date: 'April 12, 2026',
    tags: ['governance-engine', 'incorporation-heuristic', 'gateway-rules'],
    file: 'content/v0.9/part-4.md',
  },
  'part-5': {
    id: 'part-5',
    title: 'Part V — The Material Constitution of the AI Era',
    subtitle: 'Compute, Capacity, and the Constitutional Limits of Governance',
    breadcrumb: 'Part V',
    date: 'April 12, 2026',
    tags: ['material-constitution', 'sovereign-api', 'parametric-democracy'],
    file: 'content/v0.9/part-5.md',
  },
  'glossary': {
    id: 'glossary',
    title: 'Glossary',
    breadcrumb: 'Glossary',
    date: 'April 12, 2026',
    tags: ['glossary', 'key-terms'],
    file: 'content/v0.9/glossary.md',
  },
  'overview': {
    id: 'overview',
    title: 'Code After',
    subtitle: 'A Multilingual Research Programme on How AI Is Reshaping Societies and Institutions You Live In',
    breadcrumb: 'Overview',
    date: 'May 2026',
    tags: ['overview', 'research-programme', 'multilingual'],
    file: 'content/overview.md',
  },
  'faq': {
    id: 'faq',
    title: 'Code After — Frequently Asked Questions',
    breadcrumb: 'FAQ',
    date: 'May 2026',
    tags: ['faq', 'questions', 'overview'],
    file: 'content/faq.md',
  },
  'contact': {
    id: 'contact',
    title: 'Connect with Code After',
    breadcrumb: 'Contact',
    date: 'May 2026',
    tags: ['contact', 'connect'],
    file: 'content/contact.md',
  },
  'ann-front-matter': {
    id: 'ann-front-matter',
    title: 'Code After Series — A Translation Project for the AI Era',
    subtitle: 'Series Announcement Paper — Open-Access Release',
    breadcrumb: 'Code After Series > Front Matter',
    date: 'May 2026',
    tags: ['announcement', 'front-matter'],
    file: 'content/announcement/front-matter.md',
  },
  'ann-why': {
    id: 'ann-why',
    title: 'I. Why Code After',
    breadcrumb: 'Code After Series > I. Why Code After',
    date: 'May 2026',
    tags: ['announcement', 'why'],
    file: 'content/announcement/why-code-after.md',
  },
  'ann-what': {
    id: 'ann-what',
    title: 'II. What Came Before',
    breadcrumb: 'Code After Series > II. What Came Before',
    date: 'May 2026',
    tags: ['announcement', 'what-came-before'],
    file: 'content/announcement/what-came-before.md',
  },
  'ann-thesis': {
    id: 'ann-thesis',
    title: 'III. The Core Thesis',
    breadcrumb: 'Code After Series > III. The Core Thesis',
    date: 'May 2026',
    tags: ['announcement', 'core-thesis'],
    file: 'content/announcement/core-thesis.md',
  },
  'ann-gap': {
    id: 'ann-gap',
    title: 'IV. The Widening Gap',
    breadcrumb: 'Code After Series > IV. The Widening Gap',
    date: 'May 2026',
    tags: ['announcement', 'widening-gap'],
    file: 'content/announcement/widening-gap.md',
  },
  'ann-series': {
    id: 'ann-series',
    title: 'V. The Series',
    breadcrumb: 'Code After Series > V. The Series',
    date: 'May 2026',
    tags: ['announcement', 'series'],
    file: 'content/announcement/the-series.md',
  },
  'ann-outputs': {
    id: 'ann-outputs',
    title: 'VI. Layered Outputs',
    breadcrumb: 'Code After Series > VI. Layered Outputs',
    date: 'May 2026',
    tags: ['announcement', 'layered-outputs'],
    file: 'content/announcement/layered-outputs.md',
  },
  'ann-pub': {
    id: 'ann-pub',
    title: 'VII. Publication Architecture and Bilingual Commitment',
    breadcrumb: 'Code After Series > VII. Publication Architecture',
    date: 'May 2026',
    tags: ['announcement', 'publication'],
    file: 'content/announcement/publication-architecture.md',
  },
  'ann-partworks': {
    id: 'ann-partworks',
    title: 'VIII. The Partworks Model',
    breadcrumb: 'Code After Series > VIII. The Partworks Model',
    date: 'May 2026',
    tags: ['announcement', 'partworks'],
    file: 'content/announcement/partworks-model.md',
  },
  'ann-voice': {
    id: 'ann-voice',
    title: 'IX. The Voice',
    breadcrumb: 'Code After Series > IX. The Voice',
    date: 'May 2026',
    tags: ['announcement', 'voice'],
    file: 'content/announcement/the-voice.md',
  },
  'ann-why-now': {
    id: 'ann-why-now',
    title: 'X. Why This, Why Now',
    breadcrumb: 'Code After Series > X. Why This, Why Now',
    date: 'May 2026',
    tags: ['announcement', 'why-now'],
    file: 'content/announcement/why-this-why-now.md',
  },
  'ann-app-a': {
    id: 'ann-app-a',
    title: 'Appendix A',
    subtitle: 'Terms from V0.9 Used in This Paper',
    breadcrumb: 'Code After Series > Appendix A',
    date: 'May 2026',
    tags: ['announcement', 'appendix'],
    file: 'content/announcement/appendix-a.md',
  },
  'ann-app-b': {
    id: 'ann-app-b',
    title: 'Appendix B',
    subtitle: 'Terms Developed in This Paper',
    breadcrumb: 'Code After Series > Appendix B',
    date: 'May 2026',
    tags: ['announcement', 'appendix'],
    file: 'content/announcement/appendix-b.md',
  },
  'ann-toc': {
    id: 'ann-toc',
    title: 'Table of Contents',
    breadcrumb: 'Code After Series > Table of Contents',
    date: 'May 2026',
    tags: ['announcement', 'toc'],
    file: 'content/announcement/toc.md',
  },
  'ai-anc-ref': {
    id: 'ai-anc-ref',
    title: 'AI Has Ancestors Reference',
    subtitle: 'Parts One, Two & Three',
    breadcrumb: 'AI Has Ancestors > Reference',
    date: 'June 2026',
    tags: ['ai-ancestors', 'reference', 'pre-code', 'post-code'],
    file: 'content/AI_has_ancestors_series/00-Reference.md',
  },
  'ai-anc-p1': {
    id: 'ai-anc-p1',
    title: 'Part One — The Pre-Code World',
    subtitle: 'The four encoding technologies that came before artificial intelligence',
    breadcrumb: 'AI Has Ancestors > Part One',
    date: 'June 2026',
    tags: ['ai-ancestors', 'pre-code', 'writing', 'alphabet', 'printing-press', 'digital-wire'],
    file: 'content/AI_has_ancestors_series/01-Part One — The Pre-Code World.md',
  },
  'ai-anc-p2': {
    id: 'ai-anc-p2',
    title: 'Part Two — The Post-Code Break',
    subtitle: 'The fifth member crosses the line the first four never touched',
    breadcrumb: 'AI Has Ancestors > Part Two',
    date: 'June 2026',
    tags: ['ai-ancestors', 'post-code', 'tokeniser', 'chinese', 'outlier'],
    file: 'content/AI_has_ancestors_series/02-Part Two — The Post-Code Break.md',
  },
};

// Auto-import all markdown files
const modules = import.meta.glob('./content/**/*.md', { query: '?raw', import: 'default', eager: true });

// Auto-import all image files
const imageModules = import.meta.glob('./content/**/*.{png,jpg,jpeg,gif,svg}', { eager: true });

export function getContent(file: string): string {
  const fullPath = `./${file}`;
  return (modules as Record<string, string>)[fullPath] || '';
}

/** Resolve markdown image relative path to imported module URL */
export function getImageUrl(mdFilePath: string, imgRelPath: string): string {
  // mdFilePath like "content/AI_has_ancestors_series/01-xxx.md"
  // imgRelPath like "../images/xxx.png"
  const mdDir = mdFilePath.substring(0, mdFilePath.lastIndexOf('/'));
  const parts = mdDir.split('/');
  const imgParts = imgRelPath.split('/').filter((p) => p !== '.');
  for (const p of imgParts) {
    if (p === '..') {
      parts.pop();
    } else {
      parts.push(p);
    }
  }
  const resolvedPath = './' + parts.join('/');
  const mod = (imageModules as Record<string, { default?: string }>)[resolvedPath];
  return mod?.default || '';
}