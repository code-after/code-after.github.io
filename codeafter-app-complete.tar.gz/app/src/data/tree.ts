export interface TreeItem {
  id: string;
  label: string;
  path: string;
  type: 'file' | 'folder';
  children?: TreeItem[];
}

export const documentTree: TreeItem[] = [
  { id: 'home', label: 'Home', path: '/', type: 'file' },
  { id: 'overview', label: 'Overview', path: '/overview', type: 'file' },
  {
    id: 'projects',
    label: 'Code After Series',
    path: '',
    type: 'folder',
    children: [
      {
        id: 'announcement',
        label: 'Code After Series Announcement',
        path: '',
        type: 'folder',
        children: [
          { id: 'ann-toc', label: 'Table of Contents', path: '/announcement/toc', type: 'file' },
          { id: 'ann-front-matter', label: 'Front Matter', path: '/announcement/front-matter', type: 'file' },
          { id: 'ann-why', label: 'I. Why Code After', path: '/announcement/why-code-after', type: 'file' },
          { id: 'ann-what', label: 'II. What Came Before', path: '/announcement/what-came-before', type: 'file' },
          { id: 'ann-thesis', label: 'III. The Core Thesis', path: '/announcement/core-thesis', type: 'file' },
          { id: 'ann-gap', label: 'IV. The Widening Gap', path: '/announcement/widening-gap', type: 'file' },
          { id: 'ann-series', label: 'V. The Series', path: '/announcement/the-series', type: 'file' },
          { id: 'ann-outputs', label: 'VI. Layered Outputs', path: '/announcement/layered-outputs', type: 'file' },
          { id: 'ann-pub', label: 'VII. Publication Architecture', path: '/announcement/publication-architecture', type: 'file' },
          { id: 'ann-partworks', label: 'VIII. The Partworks Model', path: '/announcement/partworks-model', type: 'file' },
          { id: 'ann-voice', label: 'IX. The Voice', path: '/announcement/the-voice', type: 'file' },
          { id: 'ann-why-now', label: 'X. Why This, Why Now', path: '/announcement/why-this-why-now', type: 'file' },
          { id: 'ann-app-a', label: 'Appendix A', path: '/announcement/appendix-a', type: 'file' },
          { id: 'ann-app-b', label: 'Appendix B', path: '/announcement/appendix-b', type: 'file' },
        ],
      },
      {
        id: 'ai-ancestors',
        label: 'AI Has Ancestors',
        path: '',
        type: 'folder',
        children: [
          { id: 'ai-anc-ref', label: 'Reference', path: '/ai-ancestors/reference', type: 'file' },
          { id: 'ai-anc-p1', label: 'Part One — The Pre-Code World', path: '/ai-ancestors/part-one', type: 'file' },
          { id: 'ai-anc-p2', label: 'Part Two — The Post-Code Break', path: '/ai-ancestors/part-two', type: 'file' },
        ],
      },
      {
        id: 'book-v09',
        label: 'Code After — Law, Accounting, and the Governance of Artificial Intelligence V0.9',
        path: '',
        type: 'folder',
        children: [
          { id: 'toc', label: 'Table of Contents', path: '/toc', type: 'file' },
          { id: 'front-matter', label: 'Front Matter', path: '/front-matter', type: 'file' },
          { id: 'preface', label: 'Preface', path: '/preface', type: 'file' },
          {
            id: 'part-i',
            label: 'Part I — The Structural Diagnosis',
            path: '',
            type: 'folder',
            children: [
              { id: 'chapter-1', label: 'Ch.1 — The World States Cannot See', path: '/chapter-1', type: 'file' },
              { id: 'chapter-2', label: 'Ch.2 — The Rule-Execution Gap', path: '/chapter-2', type: 'file' },
            ],
          },
          {
            id: 'part-ii',
            label: 'Part II — The Grammar of Governance',
            path: '',
            type: 'folder',
            children: [
              { id: 'law', label: 'Sec.I — Law as the Language of Power', path: '/law', type: 'file' },
              { id: 'accounting', label: 'Sec.II — Accounting as the Language of Measurement', path: '/accounting', type: 'file' },
            ],
          },
          { id: 'part-3', label: 'Part III — The Architecture of the Global AI Stack', path: '/part-3', type: 'file' },
          { id: 'part-4', label: 'Part IV — The Governance Engine', path: '/part-4', type: 'file' },
          { id: 'part-5', label: 'Part V — The Material Constitution of the AI Era', path: '/part-5', type: 'file' },
          { id: 'glossary', label: 'Glossary', path: '/glossary', type: 'file' },
        ],
      },
    ],
  },
  { id: 'faq', label: 'FAQ', path: '/faq', type: 'file' },
  { id: 'contact', label: 'Contact', path: '/contact', type: 'file' },
];

export const pathToIdMap: Record<string, string> = {
  '/': 'home',
  '/overview': 'overview',
  '/announcement/front-matter': 'ann-front-matter',
  '/announcement/why-code-after': 'ann-why',
  '/announcement/what-came-before': 'ann-what',
  '/announcement/core-thesis': 'ann-thesis',
  '/announcement/widening-gap': 'ann-gap',
  '/announcement/the-series': 'ann-series',
  '/announcement/layered-outputs': 'ann-outputs',
  '/announcement/publication-architecture': 'ann-pub',
  '/announcement/partworks-model': 'ann-partworks',
  '/announcement/the-voice': 'ann-voice',
  '/announcement/why-this-why-now': 'ann-why-now',
  '/announcement/appendix-a': 'ann-app-a',
  '/announcement/appendix-b': 'ann-app-b',
  '/announcement/toc': 'ann-toc',
  '/toc': 'toc',
  '/front-matter': 'front-matter',
  '/preface': 'preface',
  '/chapter-1': 'chapter-1',
  '/chapter-2': 'chapter-2',
  '/law': 'law',
  '/accounting': 'accounting',
  '/part-3': 'part-3',
  '/part-4': 'part-4',
  '/part-5': 'part-5',
  '/glossary': 'glossary',
  '/faq': 'faq',
  '/contact': 'contact',
  '/ai-ancestors/reference': 'ai-anc-ref',
  '/ai-ancestors/part-one': 'ai-anc-p1',
  '/ai-ancestors/part-two': 'ai-anc-p2',
};

/** DFS flatten: collect all nodes with a non-empty path, in tree order */
export function flattenTree(items: TreeItem[]): { path: string; label: string }[] {
  const result: { path: string; label: string }[] = [];
  for (const item of items) {
    if (item.path) {
      result.push({ path: item.path, label: item.label });
    }
    if (item.children) {
      result.push(...flattenTree(item.children));
    }
  }
  return result;
}

export const idToPathMap: Record<string, string> = {
  home: '/',
  overview: '/overview',
  'ann-front-matter': '/announcement/front-matter',
  'ann-why': '/announcement/why-code-after',
  'ann-what': '/announcement/what-came-before',
  'ann-thesis': '/announcement/core-thesis',
  'ann-gap': '/announcement/widening-gap',
  'ann-series': '/announcement/the-series',
  'ann-outputs': '/announcement/layered-outputs',
  'ann-pub': '/announcement/publication-architecture',
  'ann-partworks': '/announcement/partworks-model',
  'ann-voice': '/announcement/the-voice',
  'ann-why-now': '/announcement/why-this-why-now',
  'ann-app-a': '/announcement/appendix-a',
  'ann-app-b': '/announcement/appendix-b',
  'ann-toc': '/announcement/toc',
  toc: '/toc',
  'front-matter': '/front-matter',
  preface: '/preface',
  'chapter-1': '/chapter-1',
  'chapter-2': '/chapter-2',
  law: '/law',
  accounting: '/accounting',
  'part-3': '/part-3',
  'part-4': '/part-4',
  'part-5': '/part-5',
  glossary: '/glossary',
  faq: '/faq',
  contact: '/contact',
  'ai-anc-ref': '/ai-ancestors/reference',
  'ai-anc-p1': '/ai-ancestors/part-one',
  'ai-anc-p2': '/ai-ancestors/part-two',
};
