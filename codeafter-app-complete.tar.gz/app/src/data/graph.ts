export interface GraphNode {
  id: string;
  label: string;
  x: number;
  y: number;
  radius: number;
  group: string;
}

export interface GraphEdge {
  source: string;
  target: string;
}

// 分组颜色
export const GROUP_COLORS: Record<string, string> = {
  'meta': '#9a948d',
  'part-i': '#c75c2e',
  'part-ii': '#2e7d8a',
  'part-iii': '#6b8f3c',
  'part-iv': '#8b5a9f',
  'part-v': '#b8860b',
  'announcement': '#c75c2e',
  'ai-ancestors': '#4a7c59',
};

export const graphNodes: GraphNode[] = [
  // Meta
  { id: 'home', label: 'Home', x: 140, y: 80, radius: 6, group: 'meta' },
  { id: 'overview', label: 'Overview', x: 200, y: 50, radius: 5, group: 'meta' },
  { id: 'faq', label: 'FAQ', x: 260, y: 80, radius: 5, group: 'meta' },
  { id: 'contact', label: 'Contact', x: 80, y: 50, radius: 5, group: 'meta' },
  { id: 'front-matter', label: 'Front Matter', x: 140, y: 120, radius: 5, group: 'meta' },
  { id: 'preface', label: 'Preface', x: 140, y: 160, radius: 6, group: 'meta' },
  { id: 'toc', label: 'Contents', x: 200, y: 110, radius: 4, group: 'meta' },
  { id: 'glossary', label: 'Glossary', x: 200, y: 260, radius: 5, group: 'meta' },

  // Part I — Structural Diagnosis
  { id: 'chapter-1', label: 'Ch.1: Visibility Gap', x: 100, y: 200, radius: 8, group: 'part-i' },
  { id: 'chapter-2', label: 'Ch.2: Rule-Execution Gap', x: 180, y: 200, radius: 8, group: 'part-i' },

  // Part II — Grammar of Governance
  { id: 'law', label: 'Sec.I: Law', x: 60, y: 240, radius: 6, group: 'part-ii' },
  { id: 'accounting', label: 'Sec.II: Accounting', x: 100, y: 260, radius: 6, group: 'part-ii' },

  // Part III — Global AI Stack
  { id: 'part-3', label: 'Part III: AI Stack', x: 180, y: 240, radius: 7, group: 'part-iii' },

  // Part IV — Governance Engine
  { id: 'part-4', label: 'Part IV: Governance', x: 140, y: 280, radius: 7, group: 'part-iv' },

  // Part V — Material Constitution
  { id: 'part-5', label: 'Part V: Constitution', x: 180, y: 300, radius: 8, group: 'part-v' },

  // AI Has Ancestors
  { id: 'ai-anc-ref', label: 'AI Ancestors', x: 50, y: 150, radius: 7, group: 'ai-ancestors' },
  { id: 'ai-anc-p1', label: 'Pre-Code World', x: 30, y: 180, radius: 6, group: 'ai-ancestors' },
  { id: 'ai-anc-p2', label: 'Post-Code Break', x: 70, y: 180, radius: 6, group: 'ai-ancestors' },

  // Code After Series Announcement
  { id: 'ann-why', label: 'Why Code After', x: 240, y: 160, radius: 5, group: 'announcement' },
  { id: 'ann-what', label: 'What Came Before', x: 260, y: 190, radius: 5, group: 'announcement' },
  { id: 'ann-thesis', label: 'Core Thesis', x: 240, y: 220, radius: 6, group: 'announcement' },
  { id: 'ann-gap', label: 'Widening Gap', x: 260, y: 250, radius: 5, group: 'announcement' },
  { id: 'ann-series', label: 'The Series', x: 240, y: 280, radius: 5, group: 'announcement' },
  { id: 'ann-outputs', label: 'Layered Outputs', x: 260, y: 310, radius: 4, group: 'announcement' },
  { id: 'ann-pub', label: 'Publication Arch', x: 220, y: 340, radius: 4, group: 'announcement' },
  { id: 'ann-partworks', label: 'Partworks', x: 260, y: 370, radius: 4, group: 'announcement' },
  { id: 'ann-voice', label: 'The Voice', x: 220, y: 400, radius: 4, group: 'announcement' },
  { id: 'ann-why-now', label: 'Why Now', x: 260, y: 430, radius: 4, group: 'announcement' },
];

// 语义关联边：按内容逻辑连接
export const graphEdges: GraphEdge[] = [
  // Home 连接所有顶层入口
  { source: 'home', target: 'overview' },
  { source: 'home', target: 'front-matter' },
  { source: 'home', target: 'ann-why' },
  { source: 'home', target: 'faq' },
  { source: 'home', target: 'contact' },

  // Front Matter → Preface → Chapter 1 → Chapter 2（书本阅读顺序）
  { source: 'front-matter', target: 'preface' },
  { source: 'front-matter', target: 'toc' },
  { source: 'preface', target: 'chapter-1' },
  { source: 'chapter-1', target: 'chapter-2' },

  // Chapter 2 → Law + Accounting（Part II 展开）
  { source: 'chapter-2', target: 'law' },
  { source: 'chapter-2', target: 'accounting' },

  // Law + Accounting → Part III（治理架构上升）
  { source: 'law', target: 'part-3' },
  { source: 'accounting', target: 'part-3' },

  // Part III → Part IV → Part V（递进关系）
  { source: 'part-3', target: 'part-4' },
  { source: 'part-4', target: 'part-5' },

  // Part V → Glossary（参考）
  { source: 'part-5', target: 'glossary' },
  { source: 'toc', target: 'glossary' },

  // Announcement 系列：线性阅读顺序
  { source: 'ann-why', target: 'ann-what' },
  { source: 'ann-what', target: 'ann-thesis' },
  { source: 'ann-thesis', target: 'ann-gap' },
  { source: 'ann-gap', target: 'ann-series' },
  { source: 'ann-series', target: 'ann-outputs' },
  { source: 'ann-outputs', target: 'ann-pub' },
  { source: 'ann-pub', target: 'ann-partworks' },
  { source: 'ann-partworks', target: 'ann-voice' },
  { source: 'ann-voice', target: 'ann-why-now' },

  // Announcement 与 Framework 的横向连接（核心概念对应）
  { source: 'ann-thesis', target: 'chapter-1' },     // Thesis → Visibility Gap
  { source: 'ann-thesis', target: 'chapter-2' },     // Thesis → Rule-Execution Gap
  { source: 'ann-series', target: 'part-3' },        // Series → AI Stack
  { source: 'ann-why-now', target: 'part-5' },       // Why Now → Constitution
  { source: 'overview', target: 'preface' },         // Overview → Preface

  // AI Has Ancestors 系列连接
  { source: 'home', target: 'ai-anc-ref' },          // Home → Reference
  { source: 'ai-anc-ref', target: 'ai-anc-p1' },     // Reference → Part One
  { source: 'ai-anc-p1', target: 'ai-anc-p2' },      // Part One → Part Two
  { source: 'ai-anc-p2', target: 'chapter-1' },      // Post-Code → Visibility Gap (related)
  { source: 'ai-anc-ref', target: 'overview' },      // Reference → Overview
];
