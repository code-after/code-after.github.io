## Connect

| | |
|:---|:---|
| **Project Website** | [codeafter.ai](https://codeafter.ai) |
| **ORCID** | 0009-0000-7611-6323 |
| **LinkedIn** | [Code After AI](https://www.linkedin.com/company/codeafter-ai) |
| **Substack** | [codeafter.substack.com](https://codeafter.substack.com) |
| **Email** | partners@codeafter.ai |

## Licence

Content licensed under CC BY-NC-ND 4.0.

(c) 2026 Richard Yan
