# Code After Series — A Translation Project for the AI Era

**Author:** Richard Yan

**Email:** richard.yan@codeafter.ai

**ORCID:** https://orcid.org/0009-0000-7611-6323

**Affiliation:** Code After AI

**Document type:** Series Announcement Paper — Open-Access Release

**Release date:** 8 May 2026

**Repository:** Zenodo

**DOI:** 10.5281/zenodo.20079145

**Additional dissemination:** ResearchGate; SSRN; codeafter.ai

**Length:** Approx. 11,000 words

**Language:** English (Chinese edition in parallel to follow)

## Abstract

This paper announces the **Code After Series**: six papers over twenty-four months. Each extends the framework of _Code After: Law, Accounting, and the Governance of Artificial Intelligence_ (v0.9, April 2026) into a distinct institutional domain being reshaped by AI. The paper opens by naming the structural break the project is built to address — the move from a **Pre-Code condition**, in which deterministic code was executed by transparent tools, to a **Post-Code condition**, in which probabilistic intelligence operates as a quasi-agent inside institutions built for the earlier regime. It sets out the project's core thesis — that AI is a general-purpose decoupling force acting on institutions built for stable representation — and specifies the methodological discipline, publication architecture, and distribution model through which the series will be produced and disseminated. It also serves as a formal invitation to local publishers, translators, and institutional partners positioned to produce language editions outside the G2.

## Suggested Citation

Yan, R. (2026). _Code After: A Translation Project for the AI Era_. Zenodo. DOI: 10.5281/zenodo.20079145. Also deposited on SSRN and ResearchGate.


## Companion Work

Yan, R. (2026). _Code After: Law, Accounting, and the Governance of Artificial Intelligence_ (v0.9, April 2026). Zenodo. DOI: 10.5281/zenodo.19537473. Also deposited on SSRN (ID: 6563959) and ResearchGate (Richard-Yan-10).