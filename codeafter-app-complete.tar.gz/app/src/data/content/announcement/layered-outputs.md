# VI. Layered Outputs

A single register cannot serve every reader the project is built to reach. The academic reader needs citations, methodological detail, and engagement with the relevant literatures. The policymaker needs concrete implications for the decisions they face. The professional reader needs diagnosis in the domain they work in. The general reader needs access to the argument without first becoming fluent in the disciplines it draws on. Writing for all four at once produces a register that serves none of them well.

The series addresses this through three layers: **academic papers, companion essays, and a distribution layer** of shorter public-facing pieces.

The **academic paper** is the analytical core. Full density, full citation, written for the scholarly readers whose engagement will test and refine the framework. Each of the six papers in the series will be led by an academic paper of this kind.

The **companion essay** is the reach. Shorter, less technical, written for the general reader and the policymaker. It carries the argument without the scholarly apparatus, shows what the argument means in its domain, and does most of the work of meeting readers who would not otherwise encounter the analysis. The companion essay deserves at least the editorial attention the academic paper receives, because most readers will arrive through it.

The **distribution layer** is the entry point. Op-eds, policy briefs, presentations, interviews, and explanatory material on codeafter.ai will extend specific arguments from the series into specific public conversations as occasions require.

The three layers work together as a pathway rather than as parallel products. The academic paper establishes the analysis. The companion essay translates it. The distribution layer delivers it into the conversations where the argument has to land. A reader entering through a distribution piece finds the companion essay standing behind it. A reader entering through the companion essay finds the academic paper behind that. A reader entering through the academic paper finds the framework that ties the whole series together.

The aim is fidelity across registers, not simplification. Each layer is written at the density its audience can work with. Each carries the same argument. The academic paper holds the full analysis. The companion essay carries the argument in plainer terms. The distribution layer meets readers where the conversations they are already in.

The discipline applies across languages as well as registers. Translation of frontier material whose vocabulary is not yet stable in the target language requires skilled adaptation, not mechanical conversion. Short declarative sentences travel across languages better than long subordinate constructions. The voice discipline is therefore part of the multilingual architecture from the start, not a stylistic preference layered on top.

The specific forms will develop as the series progresses and as readers emerge. The commitment to a layered architecture is fixed.