# VIII. The Partworks Model

The publication model the series is adopting has a precedent worth naming. **Partworks publishing** — the serial release of a larger body of work in instalments, with local editions produced by regional publishers under licence — was one of the most effective mass-market knowledge-distribution architectures of the late twentieth century. Italian publishers led the international expansion. RCS Libri (Rizzoli), De Agostini, and Fratelli Fabbri Editori exported partworks titles across markets and subject categories well beyond Italy.

I know this model from direct experience. Beginning in the early 1990s, I published the first Chinese editions of _PC Magazine, PC Week, PC Computing, Institutional Investor,_ and _Popular Science,_ among other titles, under licence from their originators. ZDNet was not a magazine but one of the earliest digital platform plays in China, which I built and operated under licence from the same period. I also published hundreds of global book titles in technology, finance, and the sciences, and produced partworks in China through a joint venture with RCS Libri. The computing titles in particular put me at the start of the computer and internet revolution in China. AI is the revolution now succeeding it.

What that period taught was practical. Serious content reaches general publics most reliably through fixed cadence, cumulative architecture, and local editorial partnership — not through centralised publication in a single jurisdiction or language. The knowledge travels because the structure lets it.

The Code After Series adapts that logic to the AI era. The cadence is four months per paper rather than fortnightly. The distribution is open access rather than subscription, because the mission is public good. The aim is not to reproduce the partworks model but to apply its underlying principles to a subject that no community will be able to retire from. AI will not go away for any community. The conversations and contestations it requires will happen in every community's own language — or they will not happen at all. A multilingual mechanism for sustained engagement is the only architecture that lets those conversations be honest in their own register and accountable to their own institutions.

## A. Incremental Entry

The architecture accommodates partners joining at any point. A publisher may take on Paper 1 alone and decide whether to continue. A publisher may enter at Paper 2 or 3, with earlier papers available as back-list. A publisher may take on all six as a committed programme, or select a subset by domain relevance to the local market. Arriving later does not foreclose access to what came before. Partners can begin when they are ready, and they can always go back.

## B. The Asymmetry to Acknowledge

The partworks analogy under-describes the operational challenge. Historical partworks succeeded because local publishers carried commercial risk and the originator supplied content. The Code After version inverts this. The originator carries the content risk. Local partners are asked to invest in adaptation for markets where commercial return is uncertain. The model can work — but only with partners who recognise what they themselves bring, which is editorial judgement, local institutional knowledge, distribution capacity, and the situated evidence that no central operation can produce. The partnership cannot be framed primarily in terms of what the partner receives. The partners most worth having understand this without needing it explained.

## C. Licensing and Terms

The series is released under **CC BY-NC-ND**. The project operates a **dual-licence model**: the public licence governs unmodified, non-commercial sharing, while bespoke partnership licences cover adaptation and commercial use by official partners. Non-commercial academic and policy sharing of the unmodified original materials is permitted under the public licence with attribution and without separate agreement.

Local-language editions are adaptations and require a separate licence, whether or not they are produced commercially. Non-commercial institutional editions may be handled through simplified academic or institutional terms. Commercial local-language editions — print runs, subscription distribution, bundled-with-subscription delivery, co-branded professional publications — require commercial terms in addition, negotiated bilaterally with the partner.

The default structure has three elements: an **exclusive local-language licence** for a defined language, territory, format, and term; a **revenue-share arrangement** calibrated to the partner's market and production costs; and **editorial cooperation** that preserves the framework's analytical structure, terminology, and attribution across editions while leaving local editorial decisions to the local editor. The terms scale to the partner's situation. The editorial cooperation does not.

## D. Contact

Partners interested in discussing a local-language edition should write to **partners@codeafter.ai**. The same address handles regional imprints, institutional collaborations, and bespoke publication arrangements. Inquiries are welcome from publishers, academic institutions, policy research organisations, professional services firms, and any other organisation positioned to produce serious work in a language the series does not yet serve. A short note describing the partner, the proposed language or market, and the interest in the series is sufficient to open the conversation.