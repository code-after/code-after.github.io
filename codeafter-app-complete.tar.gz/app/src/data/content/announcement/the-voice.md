# IX. The Voice

A word on register, because the writing is itself part of the argument.

Frontier scholarship has accumulated habits that often make it unreadable to readers outside its own conversation. The habits are not unreasonable. They signal disciplinary membership. They protect against overclaim. They preserve the epistemic caution the disciplines have earned through long practice. But the habits have a cost. They wall off the frontier from the readers who most need access to it, and the wall is growing.

The **Code After register** is designed to remove the wall without removing the rigour. Claims are stated directly, in short declarative sentences where possible, with qualification placed where the argument requires, not as default posture. Jargon is reserved for terms that do real analytical work. Examples are chosen to land for a reader outside the discipline the example comes from. The writing is serious without being solemn, confident without being aggressive, composed without being cold.

The register is a discipline, not a finished achievement. It is enforced in editing as well as in initial drafting. Every paragraph is tested against the standard, and where the standard slips the paragraph is rewritten.

The register has to carry across translation without losing its character. Writing for translation from the start is writing better English. Short sentences survive. Concrete nouns survive. Active verbs survive. Excessive hedging and heavily nested subordinate clauses do not, and have been pared back for reasons beyond clarity in English alone.

This matters for the bilingual and multilingual architecture the series has committed to. The voice is a shared standard across every edition. Chinese editions, local-language editions, and future adaptations are not expected to reproduce English phrasing. They are expected to reproduce the same clarity, the same discipline, and the same directness in their own language. The objective is equivalence of function, not literal correspondence of form. Collaborators and publishers joining the series inherit the standard along with the framework.

The register is the first test of the project. If the writing cannot reach the reader, the mission fails regardless of the analytical quality behind it. The series is a research program with public-facing outputs, not a set of essays with a shared brand — and the voice is what makes that distinction operational. Every paper in the series will be judged on whether the voice holds. So will this document.