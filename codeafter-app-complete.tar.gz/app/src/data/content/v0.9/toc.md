# Table of Contents

---

## Part I — The Structural Diagnosis

### Why Sovereignty No Longer Compiles: Governance after AI

#### [Chapter 1 — The World States Cannot See](/chapter-1)

- [I. The Illusion of Control](/chapter-1#i-the-illusion-of-control)
- [II. The Three Dimensions of the Visibility Gap](/chapter-1#ii-the-three-dimensions-of-the-visibility-gap)
  - [A. Technical Opacity — The Black Box Problem](/chapter-1#a-technical-opacity-the-black-box-problem)
  - [B. Jurisdictional Fragmentation — The G2 Bifurcation and G3 Ecosystems](/chapter-1#b-jurisdictional-fragmentation-the-g2-bifurcation-and-g3-ecosystems)
  - [C. Temporal Acceleration — The Speed Chasm](/chapter-1#c-temporal-acceleration-the-speed-chasm)
- [III. Why the Gap Is Built In, Not a Passing Phase](/chapter-1#iii-why-the-gap-is-built-in-not-a-passing-phase)
  - [A. The Divergent Clocks of AI and Authority](/chapter-1#a-the-divergent-clocks-of-ai-and-authority)
  - [B. Why Expertise Concentrates at the Frontier](/chapter-1#b-why-expertise-concentrates-at-the-frontier)
  - [C. The Geometry of Authority versus the Geometry of AI](/chapter-1#c-the-geometry-of-authority-versus-the-geometry-of-ai)
- [IV. Consequences of Governing Blind](/chapter-1#iv-consequences-of-governing-blind)
  - [A. Regulatory Drift — Rules Without Reach](/chapter-1#a-regulatory-drift-rules-without-reach)
  - [B. Perverse Incentives — The Performance of Compliance](/chapter-1#b-perverse-incentives-the-performance-of-compliance)
  - [C. Legitimacy Decay — Authority Without Capability](/chapter-1#c-legitimacy-decay-authority-without-capability)
  - [D. The Governance Vacuum — When Authority Has No Operator](/chapter-1#d-the-governance-vacuum-when-authority-has-no-operator)
- [V. Who Does See — The Visibility Monopoly](/chapter-1#v-who-does-see-the-visibility-monopoly)
- [VI. The Road Ahead — What the Visibility Monopoly Makes Possible](/chapter-1#vi-the-road-ahead-what-the-visibility-monopoly-makes-possible)

#### [Chapter 2 — The Rule-Execution Gap](/chapter-2)

##### Why Governance Fails at Implementation, Not Legislation

- [I. The Void: Defining the Rule-Execution Gap](/chapter-2#i-the-void-defining-the-rule-execution-gap)
  - [A. The Fairness Trap: When Math Defies Doctrine](/chapter-2#a-the-fairness-trap-when-math-defies-doctrine)
  - [B. The Transparency Paradox: The Fidelity Trade-Off](/chapter-2#b-the-transparency-paradox-the-fidelity-trade-off)
  - [C. Why the Rule-Execution Gap Persists](/chapter-2#c-why-the-rule-execution-gap-persists)
- [II. The Forces Widening the Gap](/chapter-2#ii-the-forces-widening-the-gap)
  - [A. The Epistemic Asymmetry — The Tacit Knowledge Problem](/chapter-2#a-the-epistemic-asymmetry-the-tacit-knowledge-problem)
  - [B. Temporal Acceleration — The Obsolescence Trap](/chapter-2#b-temporal-acceleration-the-obsolescence-trap)
  - [C. Jurisdictional Fragmentation — The Compliance Gridlock](/chapter-2#c-jurisdictional-fragmentation-the-compliance-gridlock)
- [III. Why Traditional Solutions Cannot Close the Gap](/chapter-2#iii-why-traditional-solutions-cannot-close-the-gap)
  - [A. More Resources — The Capacity Fallacy](/chapter-2#a-more-resources-the-capacity-fallacy)
  - [B. Faster Processes — The Speed Fallacy](/chapter-2#b-faster-processes-the-speed-fallacy)
  - [C. International Harmonisation — The Consensus Fallacy](/chapter-2#c-international-harmonisation-the-consensus-fallacy)
  - [D. More Disclosure — The Transparency Fallacy](/chapter-2#d-more-disclosure-the-transparency-fallacy)
- [IV. Professional Services as Execution Infrastructure](/chapter-2#iv-professional-services-as-execution-infrastructure)
  - [A. Cross-Jurisdictional Observation — The Visibility Advantage](/chapter-2#a-cross-jurisdictional-observation-the-visibility-advantage)
  - [B. The Mechanics of Translation — Writing the Operational Code](/chapter-2#b-the-mechanics-of-translation-writing-the-operational-code)
  - [C. Synthesis Authority — Reconciling Incompatible Sovereigns](/chapter-2#c-synthesis-authority-reconciling-incompatible-sovereigns)
  - [D. The Inversion of Governance](/chapter-2#d-the-inversion-of-governance)
- [V. Blended Templates as Operational Legislation](/chapter-2#v-blended-templates-as-operational-legislation)
  - [A. The Algorithm of Rule Selection](/chapter-2#a-the-algorithm-of-rule-selection)
  - [B. The Maximal Compliance Strategy — The Ratchet Effect](/chapter-2#b-the-maximal-compliance-strategy-the-ratchet-effect)
  - [C. Conflict Resolution — Structural Workarounds](/chapter-2#c-conflict-resolution-structural-workarounds)
  - [D. Template Propagation — The Governance Contagion](/chapter-2#d-template-propagation-the-governance-contagion)
- [VI. The Translation Layer — A Governance Class in Formation](/chapter-2#vi-the-translation-layer-a-governance-class-in-formation)
- [VII. Conclusion — Where Law Fails and Governance Begins](/chapter-2#vii-conclusion-where-law-fails-and-governance-begins)

---

## Part II — The Grammar of Governance

### The Dual Languages of Governance

#### [Section I — Law as the Language of Power](/law)

- [The First Function: Naming What Exists](/law#the-first-function-naming-what-exists)
- [The Industrial Logic versus the AI Universe](/law#the-industrial-logic-versus-the-ai-universe)
- [The Categorical Gap in Practice](/law#the-categorical-gap-in-practice)
- [The Tripartite Failure and the Broken Translator](/law#the-tripartite-failure-and-the-broken-translator)
  - [A. How Law Decides What Is AI](/law#a-how-law-decides-what-is-ai)
  - [B. The Five Functions of AI Legal Language](/law#b-the-five-functions-of-ai-legal-language)
  - [C. Limits of the Language of Law](/law#c-limits-of-the-language-of-law)
  - [D. The Translation Imperative](/law#d-the-translation-imperative)
  - [E. The Adaptive Constitution: When Private Law Outpaces Public Law](/law#e-the-adaptive-constitution-when-private-law-outpaces-public-law)
  - [F. The Constitutional Consequence](/law#f-the-constitutional-consequence)

#### [Section II — Accounting as the Language of Measurement](/accounting)

- [The Industrial Logic and the AI Mismatch](/accounting#the-industrial-logic-and-the-ai-mismatch)
- [The Rise of the Value Intermediaries](/accounting#the-rise-of-the-value-intermediaries)
- [A. The Mechanics of Recognition](/accounting#a-the-mechanics-of-recognition)
- [B. The Recognition Selection](/accounting#b-the-recognition-selection)
- [C. Accounting Authors Economic Reality](/accounting#c-accounting-authors-economic-reality)
- [D. The Measurement Gap](/accounting#d-the-measurement-gap)
- [E. Value Creation through Translation](/accounting#e-value-creation-through-translation)
- [F. The Invisible Charter](/accounting#f-the-invisible-charter)
- [G. The Delegated Interpreter](/accounting#g-the-delegated-interpreter)

---

## [Part III — The Architecture of the Global AI Stack](/part-3)

- [I. From Architecture to Implementation](/part-3#i-from-architecture-to-implementation)
- [II. The AI Governance Machine](/part-3#ii-the-ai-governance-machine)
- [III. The Arrival of Agents](/part-3#iii-the-arrival-of-agents)
- [IV. The Geopolitics of Vertical Integration](/part-3#iv-the-geopolitics-of-vertical-integration)
- [V. The Vertical Geometry of Global Influence](/part-3#v-the-vertical-geometry-of-global-influence)
- [VI. The G3 Fracture](/part-3#vi-the-g3-fracture)
- [VII. The Offramp from Dependency](/part-3#vii-the-offramp-from-dependency)

---

## [Part IV — The Governance Engine](/part-4)

### Design, Propagation, and the Incorporation Heuristic

- [I. Why the World Needs a Place Where Systems Can Talk](/part-4#i-why-the-world-needs-a-place-where-systems-can-talk)
- [II. The Architecture of the Translation Layer](/part-4#ii-the-architecture-of-the-translation-layer)
- [III. The Valuation Translator — How HKFRS Bridges GAAP and CAS](/part-4#iii-the-valuation-translator-how-hkfrs-bridges-gaap-and-cas)
- [IV. The Legal Translator — Where Rights and Obligations Compile Across the G2 Divide](/part-4#iv-the-legal-translator-where-rights-and-obligations-compile-across-the-g2-divide)
- [V. The Physical Translator — Hong Kong as Data Port in the AI Era](/part-4#v-the-physical-translator-hong-kong-as-data-port-in-the-ai-era)
- [VI. The Systemic Risk of Losing the Interface](/part-4#vi-the-systemic-risk-of-losing-the-interface)
- [VII. The Sovereignty Paradox: Maps versus Networks](/part-4#vii-the-sovereignty-paradox-maps-versus-networks)
- [VIII. The Incorporation Heuristic](/part-4#viii-the-incorporation-heuristic)
  - [A. Visibility: The Detection Test](/part-4#a-visibility-v-the-detection-test)
  - [B. Workability: The Implementation Test](/part-4#b-workability-w-the-implementation-test)
  - [C. Necessity: The Market Gravity Test](/part-4#c-necessity-n-the-market-gravity-test)
  - [D. The Result: The Framework Sort](/part-4#d-the-result-the-framework-sort)
  - [E. Raising Your Score — Strategies for Increasing Incorporation Weight](/part-4#e-raising-your-score-strategies-for-increasing-incorporation-weight)
- [IX. The Power Hierarchy — Root Access, Admin Access, and User Access](/part-4#ix-the-power-hierarchy-root-access-admin-access-and-user-access)
  - [A. The Three Global Centres (Root Access)](/part-4#a-the-three-global-centres-root-access)
  - [B. The Power Users (Admin Access)](/part-4#b-the-power-users-admin-access)
  - [C. The Permission Matrix — A Hierarchy That Is Real, but Not Closed](/part-4#c-the-permission-matrix-a-hierarchy-that-is-real-but-not-closed)
- [X. Gateway Rules — How Global Norms Move Across the World](/part-4#x-gateway-rules-how-global-norms-move-across-the-world)
  - [A. Why Gateway Rules Spread — The Economics of Convergent Design](/part-4#a-why-gateway-rules-spread-the-economics-of-convergent-design)
  - [B. The Golden Image — How Templates Spread the Rule](/part-4#b-the-golden-image-how-templates-spread-the-rule)
  - [C. Three Ways Rules Travel](/part-4#c-three-ways-rules-travel)
  - [D. From Description to Design](/part-4#d-from-description-to-design)
  - [E. Strategies for Non-G3 Countries — Designing for Incorporation](/part-4#e-strategies-for-non-g3-countries-designing-for-incorporation)
- [XI. Conclusion — The Invisible Constitution](/part-4#xi-conclusion-the-invisible-constitution)

---

## [Part V — The Material Constitution of the AI Era](/part-5)

### Compute, Capacity, and the Constitutional Limits of Governance

- [I. The New Assets: Compute, Data, Models](/part-5#i-the-new-assets-compute-data-models)
  - [A. Compute — The Engine](/part-5#a-compute-the-engine)
  - [B. Data — The Fuel](/part-5#b-data-the-fuel)
  - [C. Models — The Territory](/part-5#c-models-the-territory)
  - [D. The Triad in Practice — A Single Scenario](/part-5#d-the-triad-in-practice-a-single-scenario)
  - [E. Transition — From Assets to Constraints](/part-5#e-transition-from-assets-to-constraints)
- [II. The Legitimacy Crisis — The Widening Gap Between Statute and AI Governance](/part-5#ii-the-legitimacy-crisis-the-widening-gap-between-statute-and-ai-governance)
  - [A. The Shift of Authority — From Institutional Control to AI-Driven Execution](/part-5#a-the-shift-of-authority-from-institutional-control-to-ai-driven-execution)
  - [B. The Five Non-Substitutable Constraints](/part-5#b-the-five-non-substitutable-constraints)
  - [C. The Gradients of Operational Agency](/part-5#c-the-gradients-of-operational-agency)
  - [D. Legitimacy Debt — The Silent Failure Mode](/part-5#d-legitimacy-debt-the-silent-failure-mode)
  - [E. What Legitimacy Collapse Looks Like](/part-5#e-what-legitimacy-collapse-looks-like)
  - [F. The New Test of Legitimacy — Consent versus Execution](/part-5#f-the-new-test-of-legitimacy-consent-versus-execution)
  - [G. The Five Design Conditions for AI Legitimacy](/part-5#g-the-five-design-conditions-for-ai-legitimacy)
- [III. Code After: The Operating Manual for the AI Era](/part-5#iii-code-after-the-operating-manual-for-the-ai-era)
  - [A. The Sovereign API](/part-5)
  - [B. Parametric Democracy — Governing at Machine Speed](/part-5)
  - [C. The Protocol of Federation — Interoperability Without Harmonisation](/part-5)
  - [D. The Four-Tier Constitutional Design and the Role of Licensed Operators](/part-5)
  - [E. Calibration Events — Democratic Revision at Machine Speed](/part-5)
  - [F. The Hard Problems — Inherent Tensions That Remain](/part-5)
  - [G. The Interdisciplinary Necessity](/part-5)
  - [H. Closing the Loop — The Visibility Gap Revisited](/part-5)

---

## [Glossary](/glossary)