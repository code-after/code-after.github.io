import { useRef, useEffect, useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Globe, Focus } from 'lucide-react';
import { graphNodes, graphEdges } from '../data/graph';
import { idToPathMap } from '../data/tree';

interface GraphCanvasProps {
  activeNodeId: string;
}

export default function GraphCanvas({ activeNodeId }: GraphCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const navigate = useNavigate();
  const animRef = useRef<number>(0);
  const nodePositions = useRef(graphNodes.map((n) => ({ ...n, vx: 0, vy: 0 })));
  const hoverNode = useRef<string | null>(null);
  const isDragging = useRef(false);
  const dragNode = useRef<string | null>(null);
  const isPanning = useRef(false);
  const panStart = useRef({ sx: 0, sy: 0, cx: 0, cy: 0 });
  const camera = useRef({ scale: 1, ox: 0, oy: 0 });
  const [localMode, setLocalMode] = useState(true);

  const CANVAS_W = 280;
  const CANVAS_H = 290;
  const MIN_SCALE = 0.5;
  const MAX_SCALE = 5;

  const getVisibleNodes = useCallback(() => {
    if (!localMode) return new Set(graphNodes.map((n) => n.id));
    const visible = new Set<string>();
    visible.add(activeNodeId);
    for (const edge of graphEdges) {
      if (edge.source === activeNodeId) visible.add(edge.target);
      if (edge.target === activeNodeId) visible.add(edge.source);
    }
    return visible;
  }, [activeNodeId, localMode]);

  // Screen -> World (accounting for camera)
  const screenToWorld = (sx: number, sy: number) => ({
    x: (sx - camera.current.ox) / camera.current.scale,
    y: (sy - camera.current.oy) / camera.current.scale,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    canvas.width = CANVAS_W * dpr;
    canvas.height = CANVAS_H * dpr;

    const MAX_VELOCITY = 3;

    const animate = () => {
      const nodes = nodePositions.current;
      const visible = getVisibleNodes();
      const frozen = hoverNode.current !== null;
      const cam = camera.current;

      // ===== Physics (freeze on hover) =====
      if (!frozen) {
        for (let i = 0; i < nodes.length; i++) {
          for (let j = i + 1; j < nodes.length; j++) {
            const vF = visible.has(nodes[i].id) && visible.has(nodes[j].id) ? 1 : 0.15;
            const dx = nodes[j].x - nodes[i].x;
            const dy = nodes[j].y - nodes[i].y;
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            const cDist = Math.max(dist, 20);
            const force = (120 / (cDist * cDist)) * vF;
            nodes[i].vx -= (dx / dist) * force;
            nodes[i].vy -= (dy / dist) * force;
            nodes[j].vx += (dx / dist) * force;
            nodes[j].vy += (dy / dist) * force;
          }
        }
        for (const edge of graphEdges) {
          const src = nodes.find((n) => n.id === edge.source);
          const tgt = nodes.find((n) => n.id === edge.target);
          if (!src || !tgt) continue;
          const isFE = edge.source === activeNodeId || edge.target === activeNodeId;
          const dx = tgt.x - src.x;
          const dy = tgt.y - src.y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const force = (dist - 60) * 0.005 * (isFE ? 1.2 : 0.6);
          src.vx += (dx / dist) * force;
          src.vy += (dy / dist) * force;
          tgt.vx -= (dx / dist) * force;
          tgt.vy -= (dy / dist) * force;
        }
        for (const node of nodes) {
          const s = node.id === activeNodeId ? 0.008 : visible.has(node.id) ? 0.002 : 0.0005;
          node.vx += (CANVAS_W / 2 - node.x) * s;
          node.vy += (CANVAS_H / 2 - node.y) * s;
        }
        for (const node of nodes) {
          if (isDragging.current && dragNode.current === node.id) continue;
          node.vx *= 0.88;
          node.vy *= 0.88;
          const v = Math.sqrt(node.vx * node.vx + node.vy * node.vy);
          if (v > MAX_VELOCITY) { node.vx = (node.vx / v) * MAX_VELOCITY; node.vy = (node.vy / v) * MAX_VELOCITY; }
          node.x += node.vx;
          node.y += node.vy;
          node.x = Math.max(15, Math.min(CANVAS_W - 15, node.x));
          node.y = Math.max(15, Math.min(CANVAS_H - 15, node.y));
        }
      }

      // ===== Render with camera transform =====
      // setTransform completely replaces the matrix (no accumulation)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);
      ctx.translate(cam.ox, cam.oy);
      ctx.scale(cam.scale, cam.scale);

      const focusId = hoverNode.current;
      const isDark = document.documentElement.classList.contains('dark');
      const C_NODE_DEF = isDark ? '#888888' : '#5a5550';
      const C_NODE_HOV = 'rgb(184, 134, 11)';
      const C_NODE_DIM = isDark ? 'rgba(100,100,100,0.3)' : 'rgba(196,191,182,0.25)';
      const C_EDGE_DEF = isDark ? 'rgba(100,100,100,0.3)' : 'rgba(196,191,182,0.2)';
      const C_EDGE_HOV = 'rgba(184, 134, 11, 0.35)';
      const C_EDGE_DIM = isDark ? 'rgba(100,100,100,0.1)' : 'rgba(196,191,182,0.06)';
      const C_LABEL = isDark ? '#c0c0c0' : '#2d2b27';

      // Edges
      ctx.lineWidth = 1;
      for (const edge of graphEdges) {
        const src = nodes.find((n) => n.id === edge.source);
        const tgt = nodes.find((n) => n.id === edge.target);
        if (!src || !tgt) continue;
        if (localMode && (!visible.has(edge.source) || !visible.has(edge.target))) continue;
        const isCF = focusId && (edge.source === focusId || edge.target === focusId);
        ctx.strokeStyle = focusId ? (isCF ? C_EDGE_HOV : C_EDGE_DIM) : C_EDGE_DEF;
        ctx.beginPath();
        ctx.moveTo(src.x, src.y);
        ctx.lineTo(tgt.x, tgt.y);
        ctx.stroke();
      }

      // Nodes
      for (const node of nodes) {
        if (localMode && !visible.has(node.id)) continue;
        const isF = focusId === node.id;
        const isN = focusId ? graphEdges.some(
          (e) => (e.source === focusId && e.target === node.id) || (e.target === focusId && e.source === node.id)
        ) : false;

        let col: string;
        if (focusId) { if (isF) col = C_NODE_HOV; else if (isN) col = C_NODE_DEF; else col = C_NODE_DIM; }
        else col = C_NODE_DEF;

        const r = node.radius || 5;
        ctx.beginPath();
        ctx.arc(node.x, node.y, r, 0, Math.PI * 2);
        ctx.fillStyle = col;
        ctx.fill();
      }

      // Labels
      for (const node of nodes) {
        if (localMode && !visible.has(node.id)) continue;
        const isF = focusId === node.id;
        const isN = focusId ? graphEdges.some(
          (e) => (e.source === focusId && e.target === node.id) || (e.target === focusId && e.source === node.id)
        ) : false;
        if (!localMode && focusId && !isF && !isN) continue;

        const r = node.radius || 5;
        const fs = isF ? 10 : 8;
        const off = isF ? 16 : 11;
        ctx.fillStyle = C_LABEL;
        ctx.font = `${isF ? 500 : 400} ${fs}px 'Inter',sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(node.label, node.x, node.y + r + off);
      }

      animRef.current = requestAnimationFrame(animate);
    };

    animate();
    return () => cancelAnimationFrame(animRef.current);
  }, [activeNodeId, localMode, getVisibleNodes]);

  // Hit test with camera
  const getNodeAtPos = (clientX: number, clientY: number) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return null;
    const world = screenToWorld(clientX - rect.left, clientY - rect.top);
    const visible = getVisibleNodes();
    for (const node of nodePositions.current) {
      if (localMode && !visible.has(node.id)) continue;
      const r = node.radius || 5;
      const dx = world.x - node.x;
      const dy = world.y - node.y;
      if (dx * dx + dy * dy <= (r + 5) * (r + 5)) return node.id;
    }
    return null;
  };

  // ===== Event handlers =====
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const world = screenToWorld(mx, my);
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    const ns = Math.max(MIN_SCALE, Math.min(MAX_SCALE, camera.current.scale * delta));
    camera.current.ox = mx - world.x * ns;
    camera.current.oy = my - world.y * ns;
    camera.current.scale = ns;
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isPanning.current) {
      camera.current.ox = panStart.current.cx + (e.clientX - panStart.current.sx);
      camera.current.oy = panStart.current.cy + (e.clientY - panStart.current.sy);
      return;
    }
    const nodeId = getNodeAtPos(e.clientX, e.clientY);
    hoverNode.current = nodeId;
    if (canvasRef.current) canvasRef.current.style.cursor = nodeId ? 'pointer' : 'grab';

    // Drag node (in world coords)
    if (isDragging.current && dragNode.current) {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (rect) {
        const node = nodePositions.current.find((n) => n.id === dragNode.current);
        if (node) {
          const w = screenToWorld(e.clientX - rect.left, e.clientY - rect.top);
          node.x = w.x; node.y = w.y; node.vx = 0; node.vy = 0;
        }
      }
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const nodeId = getNodeAtPos(e.clientX, e.clientY);
    if (nodeId) { isDragging.current = true; dragNode.current = nodeId; }
    else {
      // Pan view
      isPanning.current = true;
      panStart.current = { sx: e.clientX, sy: e.clientY, cx: camera.current.ox, cy: camera.current.oy };
      if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
    }
  };

  const handleMouseUp = () => {
    isDragging.current = false;
    dragNode.current = null;
    isPanning.current = false;
    if (canvasRef.current) canvasRef.current.style.cursor = 'grab';
  };

  const handleMouseLeave = () => {
    hoverNode.current = null;
    isPanning.current = false;
  };

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging.current) return;
    const nodeId = getNodeAtPos(e.clientX, e.clientY);
    if (nodeId) { const p = idToPathMap[nodeId]; if (p) { navigate(p); setLocalMode(true); } }
  };

  return (
    <div>
      <div style={{ padding: '16px 20px 8px', fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif", fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 2, color: 'var(--ca-text-secondary)' }}>
        Interactive Graph
      </div>
      <div style={{ padding: '0 10px', position: 'relative', width: CANVAS_W + 20, boxSizing: 'border-box' }}>
        {/* Mode toggle button — top-right inside canvas area */}
        <button
          onClick={() => setLocalMode(!localMode)}
          title={localMode ? 'Switch to Global Graph' : 'Switch to Local Graph'}
          style={{
            position: 'absolute',
            top: 4,
            right: 14,
            zIndex: 10,
            background: 'transparent',
            border: 'none',
            borderRadius: 4,
            padding: 4,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--ca-text-secondary)',
            transition: 'color 200ms, background 200ms',
            backdropFilter: 'blur(2px)',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--ca-text)';
            e.currentTarget.style.backgroundColor = 'var(--ca-hover-bg)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--ca-text-secondary)';
            e.currentTarget.style.backgroundColor = 'transparent';
          }}
        >
          {localMode ? <Globe size={13} /> : <Focus size={13} />}
        </button>
        <canvas
          ref={canvasRef}
          width={CANVAS_W}
          height={CANVAS_H}
          style={{
            width: CANVAS_W,
            height: CANVAS_H,
            borderRadius: 8,
            border: '1px solid var(--ca-border)',
            backgroundColor: 'var(--ca-bg-canvas)',
            cursor: 'grab',
            display: 'block',
          }}
          onMouseMove={handleMouseMove}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseLeave}
          onWheel={handleWheel}
          onClick={handleClick}
        />
      </div>
    </div>
  );
}
