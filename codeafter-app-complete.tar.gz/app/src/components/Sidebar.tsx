import { Search, Moon, Sun } from 'lucide-react';
import { documentTree } from '../data/tree';
import TreeNode from './TreeNode';

interface SidebarProps {
  open: boolean;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  isMobile?: boolean;
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
  sidebarWidth?: number;
}

export default function Sidebar({ open, searchQuery, onSearchChange, isMobile, darkMode, onToggleDarkMode, sidebarWidth = 420 }: SidebarProps) {

  return (
    <>
      <style>{`#sidebar-scroll::-webkit-scrollbar { display: none; }`}</style>
      <aside
        style={{
          position: 'fixed',
          top: isMobile ? 48 : 0,
          left: 0,
          width: open ? sidebarWidth : 0,
          height: isMobile ? 'calc(100dvh - 48px)' : '100vh',
          backgroundColor: 'var(--ca-bg-sidebar)',
          borderRight: open ? '1px solid var(--ca-border)' : 'none',
          overflowX: 'hidden',
          overflowY: 'hidden',
          transition: 'width 300ms ease-in-out, background-color 200ms, border-color 200ms',
          display: 'flex',
          flexDirection: 'column',
          zIndex: isMobile ? 70 : 50,
          boxShadow: isMobile && open ? '2px 0 8px rgba(0,0,0,0.15)' : 'none',
        }}
      >
        <div
          style={{
            width: isMobile ? '100%' : 320,
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            minHeight: 0, // allow flex item to shrink for nested scroll
            marginLeft: isMobile ? 0 : 'auto',
            marginRight: isMobile ? 0 : 20,
            padding: isMobile ? '0 12px' : 0,
            boxSizing: 'border-box',
          }}
        >
          {/* Logo area — 手机模式隐藏 */}
          {!isMobile && (
            <div style={{ padding: '20px 0 12px 20px' }}>
              <div
                style={{
                  fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
                  fontSize: 15,
                  fontWeight: 600,
                  color: 'var(--ca-accent)',
                  letterSpacing: 0.3,
                }}
              >
                Code After
              </div>
              <div
                style={{
                  fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
                  fontSize: 11,
                  color: 'var(--ca-text-secondary)',
                  marginTop: 4,
                  lineHeight: 1.4,
                }}
              >
                A Knowledge Lab for AI Governance
              </div>
            </div>
          )}

          {/* Dark mode toggle */}
          {!isMobile && onToggleDarkMode && (
            <div style={{ padding: '4px 0 8px 20px' }}>
              <button
                onClick={onToggleDarkMode}
                title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
                style={{
                  background: 'none',
                  border: '1px solid var(--ca-border)',
                  cursor: 'pointer',
                  padding: '4px 10px',
                  borderRadius: 16,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  color: 'var(--ca-text-secondary)',
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 11,
                  transition: 'color 200ms, background 200ms, border-color 200ms',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = 'var(--ca-text)';
                  e.currentTarget.style.borderColor = 'var(--ca-border)';
                  e.currentTarget.style.backgroundColor = 'var(--ca-hover-bg)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = 'var(--ca-text-secondary)';
                  e.currentTarget.style.borderColor = 'var(--ca-border)';
                  e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                {darkMode ? <Sun size={12} /> : <Moon size={12} />}
                {darkMode ? 'Light' : 'Dark'}
              </button>
            </div>
          )}

          {/* Search bar */}
          <div style={{ padding: '12px 8px 12px 20px' }}>
            <div style={{ position: 'relative' }}>
              <Search
                size={14}
                style={{
                  position: 'absolute',
                  left: 20,
                  top: '50%',
                  transform: 'translateY(-50%)',
                  color: 'var(--ca-text-secondary)',
                  pointerEvents: 'none',
                }}
              />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search Code After..."
                style={{
                  width: '100%',
                  height: 32,
                  padding: '0 10px 0 36px',
                  borderRadius: 6,
                  border: '1px solid var(--ca-border)',
                  backgroundColor: 'var(--ca-code-bg)',
                  fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
                  fontSize: 13,
                  color: 'var(--ca-text)',
                  outline: 'none',
                  transition: 'border-color 200ms, box-shadow 200ms, background-color 200ms',
                  boxSizing: 'border-box',
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = 'var(--ca-accent)';
                  e.currentTarget.style.boxShadow = '0 0 0 2px var(--ca-accent-light)';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = 'var(--ca-border)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              />
            </div>
          </div>

          {/* Document tree — fixed width, hidden scrollbar */}
          <div
            id="sidebar-scroll"
            style={{
              flex: 1,
              minHeight: 0,
              overflowY: 'auto',
              scrollbarWidth: 'none',
              padding: '4px 0',
              marginLeft: 0,
            }}
          >
            {documentTree.map((item) => (
              <TreeNode key={item.id} item={item} depth={1} searchQuery={searchQuery} />
            ))}
          </div>
        </div>
      </aside>
    </>
  );
}
