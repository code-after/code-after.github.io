import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

interface OutlineItem {
  text: string;
  id: string;
  level: number;
}

interface PageOutlineProps {
  contentRef: React.RefObject<HTMLDivElement | null>;
}

export default function PageOutline({ contentRef }: PageOutlineProps) {
  const [items, setItems] = useState<OutlineItem[]>([]);
  const [activeId, setActiveId] = useState<string>('');
  const location = useLocation();

  useEffect(() => {
    const el = contentRef.current;
    if (!el) return;

    const headings = el.querySelectorAll('h2, h3');
    const outlineItems: OutlineItem[] = [];
    headings.forEach((heading) => {
      // Use existing id from slugify, or generate fallback
      const id = heading.id || `outline-heading-${outlineItems.length}`;
      if (!heading.id) heading.id = id;
      outlineItems.push({
        text: heading.textContent || '',
        id,
        level: heading.tagName === 'H2' ? 2 : 3,
      });
    });
    setItems(outlineItems);

    // Scroll spy
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id);
          }
        }
      },
      { rootMargin: '-80px 0px -60% 0px', threshold: 0 }
    );

    headings.forEach((h) => observer.observe(h));
    return () => observer.disconnect();
  }, [location.pathname, contentRef]);

  const handleClick = (id: string) => {
    const el = document.getElementById(id);
    const scroller = contentRef.current;
    if (el && scroller) {
      const targetTop = el.offsetTop - 20;
      scroller.scrollTop = Math.max(0, targetTop);
    }
  };

  if (items.length === 0) return null;

  return (
    <div style={{ width: 300, marginLeft: 0 }}>
      <style>{`.page-outline-scroll::-webkit-scrollbar { display: none; }`}</style>
      <div
        style={{
          fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
          fontSize: 10,
          fontWeight: 600,
          textTransform: 'uppercase' as const,
          letterSpacing: 2,
          color: 'var(--ca-text-secondary)',
          padding: '20px 20px 8px',
        }}
      >
        On This Page
      </div>
      <div className="page-outline-scroll" style={{ padding: '0 16px 16px', maxHeight: 'calc(100vh - 48px - 200px - 170px)', overflowY: 'auto', scrollbarWidth: 'none' }}>
        {items.map((item) => {
          const isActive = activeId === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleClick(item.id)}
              style={{
                display: 'block',
                width: '100%',
                textAlign: 'left',
                border: 'none',
                background: 'none',
                cursor: 'pointer',
                fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
                fontSize: item.level === 2 ? 13 : 12,
                fontWeight: item.level === 2 ? 500 : 400,
                color: isActive ? 'var(--ca-accent)' : item.level === 2 ? 'var(--ca-text)' : 'var(--ca-icon)',
                padding: `4px 0 4px ${item.level === 3 ? 12 : 0}px`,
                borderLeft: isActive ? '2px solid #b8860b' : '2px solid transparent',
                transition: 'color 150ms',
                lineHeight: 1.4,
              }}
              onMouseEnter={(e) => {
                if (!isActive) e.currentTarget.style.color = 'var(--ca-accent)';
              }}
              onMouseLeave={(e) => {
                if (!isActive) e.currentTarget.style.color = item.level === 2 ? 'var(--ca-text)' : 'var(--ca-icon)';
              }}
            >
              {item.text}
            </button>
          );
        })}
      </div>
    </div>
  );
}
