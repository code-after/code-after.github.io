import { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import type { TreeItem } from '../data/tree';

// Guide line / highlight x-position for each depth
const GUIDE_X = [6, 20, 34, 48, 62];

interface TreeNodeProps {
  item: TreeItem;
  depth: number;
  searchQuery: string;
}

export default function TreeNode({ item, depth, searchQuery }: TreeNodeProps) {
  const [expanded, setExpanded] = useState(depth === 1 && item.id === 'projects');
  const navigate = useNavigate();
  const location = useLocation();
  const isActive = location.pathname === item.path;

  const matchesSearch = searchQuery
    ? item.label.toLowerCase().includes(searchQuery.toLowerCase())
    : true;

  const hasMatchingChildren = item.children?.some(
    (child) =>
      child.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
      child.children?.some((gc) => gc.label.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const isVisible = matchesSearch || hasMatchingChildren || !searchQuery;

  if (!isVisible) return null;

  const guideX = GUIDE_X[depth] ?? 6 + depth * 14;
  const contentPad = guideX + 16;
  const CHEVRON_OFFSET = 14;

  if (item.type === 'folder') {
    const childGuideX = GUIDE_X[depth + 1] ?? 6 + (depth + 1) * 14;

    return (
      <div>
        {/* Folder header with highlight bar */}
        <div style={{ position: 'relative' }}>
          {/* Highlight bar */}
          <div
            style={{
              position: 'absolute',
              left: guideX,
              top: 0,
              bottom: 0,
              width: 2,
              backgroundColor: isActive ? 'var(--ca-accent)' : 'transparent',
              transition: 'background-color 150ms ease',
              zIndex: 1,
            }}
          />
          <button
            data-nav-item
            onClick={() => setExpanded(!expanded)}
            style={{
              display: 'flex',
              alignItems: 'center',
              width: '100%',
              padding: `3px 8px 3px ${contentPad - CHEVRON_OFFSET}px`,
              border: 'none',
              background: 'none',
              cursor: 'pointer',
              fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
              fontSize: 13,
              fontWeight: 600,
              color: isActive ? 'var(--ca-accent)' : 'var(--ca-text)',
              textAlign: 'left',
              gap: 2,
              lineHeight: 1.5,
              transition: 'color 150ms ease',
            }}
            onMouseEnter={(e) => {
              if (!isActive) {
                e.currentTarget.style.color = 'var(--ca-accent)';
                const bar = e.currentTarget.parentElement?.querySelector('[data-highlight]') as HTMLElement;
                if (bar) bar.style.backgroundColor = 'var(--ca-accent)';
              }
            }}
            onMouseLeave={(e) => {
              if (!isActive) {
                e.currentTarget.style.color = 'var(--ca-text)';
                const bar = e.currentTarget.parentElement?.querySelector('[data-highlight]') as HTMLElement;
                if (bar) bar.style.backgroundColor = 'transparent';
              }
            }}
          >
            <ChevronRight
              size={12}
              style={{
                transform: expanded ? 'rotate(90deg)' : 'rotate(0deg)',
                transition: 'transform 150ms ease',
                color: 'var(--ca-text-secondary)',
                flexShrink: 0,
                marginTop: 1,
              }}
            />
            <span style={{ whiteSpace: 'normal' }}>{item.label}</span>
          </button>
        </div>
        {/* Children with guide line */}
        {expanded && item.children && (
          <div style={{ position: 'relative' }}>
            <div
              style={{
                position: 'absolute',
                left: childGuideX,
                top: 0,
                bottom: 0,
                width: 1,
                backgroundColor: 'var(--ca-border)',
                zIndex: 0,
              }}
            />
            {item.children.map((child) => (
              <TreeNode key={child.id} item={child} depth={depth + 1} searchQuery={searchQuery} />
            ))}
          </div>
        )}
      </div>
    );
  }

  // File item
  return (
    <div style={{ position: 'relative' }}>
      {/* Highlight bar */}
      <div
        data-highlight
        style={{
          position: 'absolute',
          left: guideX,
          top: 0,
          bottom: 0,
          width: 2,
          backgroundColor: isActive ? 'var(--ca-accent)' : 'transparent',
          transition: 'background-color 150ms ease',
          zIndex: 1,
        }}
      />
      <button
        data-nav-item
        onClick={() => item.path && navigate(item.path)}
        style={{
          display: 'block',
          width: '100%',
          padding: `3px 8px 3px ${contentPad}px`,
          border: 'none',
          background: 'transparent',
          cursor: item.path ? 'pointer' : 'default',
          fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
          fontSize: 13,
          fontWeight: depth <= 1 || isActive ? 600 : 400,
          color: isActive ? 'var(--ca-accent)' : 'var(--ca-text-secondary)',
          textAlign: 'left',
          lineHeight: 1.5,
          transition: 'color 150ms ease',
        }}
        onMouseEnter={(e) => {
          if (!isActive) {
            e.currentTarget.style.color = 'var(--ca-accent)';
            const bar = e.currentTarget.parentElement?.querySelector('[data-highlight]') as HTMLElement;
            if (bar) bar.style.backgroundColor = 'var(--ca-accent)';
          }
        }}
        onMouseLeave={(e) => {
          if (!isActive) {
            e.currentTarget.style.color = 'var(--ca-text-secondary)';
            const bar = e.currentTarget.parentElement?.querySelector('[data-highlight]') as HTMLElement;
            if (bar) bar.style.backgroundColor = 'transparent';
          }
        }}
      >
        {item.label}
      </button>
    </div>
  );
}
