import { Mail, Globe, BookOpen, Linkedin, Archive } from 'lucide-react';
import GraphCanvas from './GraphCanvas';
import PageOutline from './PageOutline';

interface RightPanelProps {
  activeNodeId: string;
  contentRef: React.RefObject<HTMLDivElement | null>;
}

export default function RightPanel({ activeNodeId, contentRef }: RightPanelProps) {
  return (
    <>
      <style>{`#right-panel::-webkit-scrollbar { display: none; }`}</style>
    <aside id="right-panel"
      style={{
        position: 'fixed',
        top: 0,
        right: 0,
        width: 360,
        height: '100vh',
        backgroundColor: 'var(--ca-bg-panel)',
        zIndex: 40,
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <div style={{ flex: 1, overflowY: 'auto', scrollbarWidth: 'none' }}>
        <GraphCanvas activeNodeId={activeNodeId} />
        <PageOutline contentRef={contentRef} />
      </div>
      {/* Copyright footer */}
      <footer
        style={{
          padding: '8px 12px',
          fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
          fontSize: 11,
          color: 'var(--ca-text-secondary)',
          lineHeight: 1.5,
          textAlign: 'right',
          flexShrink: 0,
        }}
      >
        <div style={{ display: 'flex', gap: 10, marginBottom: 4, justifyContent: 'flex-end' }}>
          <a href="mailto:partners@codeafter.ai" title="Email" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><Mail size={14} /></a>
          <a href="https://codeafter.ai" target="_blank" rel="noopener noreferrer" title="Website" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><Globe size={14} /></a>
          <a href="https://codeafter.substack.com" target="_blank" rel="noopener noreferrer" title="Substack" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><BookOpen size={14} /></a>
          <a href="https://www.linkedin.com/company/codeafter-ai" target="_blank" rel="noopener noreferrer" title="LinkedIn" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><Linkedin size={14} /></a>
          <a href="https://zenodo.org/communities/code-after" target="_blank" rel="noopener noreferrer" title="Zenodo" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><Archive size={14} /></a>
        </div>
        <div>&copy; Richard Yan · <a href="#/contact" style={{ color: 'var(--ca-text-secondary)', textDecoration: 'underline' }}>Contact</a> · <a href="#/faq" style={{ color: 'var(--ca-text-secondary)', textDecoration: 'underline' }}>FAQ</a></div>
        <div>Content licensed under CC BY-NC-ND 4.0</div>
      </footer>
    </aside>
    </>
  );
}
