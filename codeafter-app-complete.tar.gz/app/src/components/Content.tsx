import { useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useLocation, useNavigate } from 'react-router-dom';
import { Mail, Globe, BookOpen, Linkedin, Archive } from 'lucide-react';
import { chapters, getContent, getImageUrl } from '../data/meta';
import { pathToIdMap, flattenTree, documentTree } from '../data/tree';

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

interface ContentProps {
  isMobile?: boolean;
  contentRef?: React.RefObject<HTMLDivElement | null>;
  showFooter?: boolean;
}

export default function Content({ isMobile, contentRef, showFooter }: ContentProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const innerRef = useRef<HTMLDivElement>(null);

  // Use external ref if provided, otherwise use internal ref
  const scrollRef = contentRef || innerRef;

  const chapter = chapters[pathToIdMap[location.pathname] || 'home'] || chapters['home'];

  useEffect(() => {
    // Reset browser scroll to prevent native anchor scrolling
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;

    const scroller = scrollRef.current;
    if (!scroller) return;

    // Reset container scroll
    scroller.scrollTop = 0;

    // Scroll to hash anchor after content renders
    if (location.hash) {
      const anchorId = location.hash.slice(1);
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          const el = document.getElementById(anchorId);
          if (el && scroller) {
            const targetTop = el.offsetTop - 20;
            scroller.scrollTop = Math.max(0, targetTop);
          }
        });
      });
    }
  }, [location.pathname, location.hash]);

  return (
    <>
      <style>{`
        [data-content-scroll]::-webkit-scrollbar { display: none; }
        @media (min-width: 1300px) { [data-content-scroll] { width: calc(100% - 360px) !important; } }
      `}</style>
      <div
        data-content-scroll
        style={{
          width: '100%',
          height: '100%',
          overflowY: 'auto',
          scrollbarWidth: 'none',
          backgroundColor: 'var(--ca-bg)',
        }}
        ref={scrollRef as React.Ref<HTMLDivElement>}
      >
        <div
          style={{
            maxWidth: 800,
            margin: '0 auto',
            padding: isMobile ? '24px 16px 30px' : '20px 32px 40px',
          }}
        >
        {/* Title */}
        <h1
          style={{
            fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
            fontSize: isMobile ? 26 : 36,
            fontWeight: 800,
            color: 'var(--ca-text)',
            marginTop: 16,
            lineHeight: 1.2,
            borderBottom: '1px solid var(--ca-border)',
            paddingBottom: 12,
            letterSpacing: -0.5,
          }}
        >
          {chapter.title}
        </h1>

        {/* Subtitle */}
        {chapter.subtitle && (
          <p
            style={{
              fontFamily: "'Source Serif 4', Georgia, serif",
              fontSize: 20,
              fontStyle: 'italic',
              fontWeight: 400,
              color: 'var(--ca-icon)',
              marginTop: 8,
            }}
          >
            {chapter.subtitle}
          </p>
        )}

        {/* Badges — home page only */}
        {location.pathname === '/' && (
          <div style={{ marginTop: 12, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            <a href="https://github.com/code-after" target="_blank" rel="noopener noreferrer">
              <img src="https://img.shields.io/badge/GitHub-code--after-1a2a3a?logo=github" alt="GitHub" />
            </a>
            <a href="https://github.com/code-after/code-after.github.io/blob/main/License.md" target="_blank" rel="noopener noreferrer">
              <img src="https://img.shields.io/badge/License-MIT-green" alt="License" />
            </a>
            <a href="https://www.linkedin.com/company/codeafter-ai" target="_blank" rel="noopener noreferrer">
              <img src="https://img.shields.io/badge/LinkedIn-Connect-0A66C2?logo=linkedin" alt="LinkedIn" />
            </a>
            <a href="https://codeafter.substack.com" target="_blank" rel="noopener noreferrer">
              <img src="https://img.shields.io/badge/Substack-Follow-FF6719?logo=substack" alt="Substack" />
            </a>
          </div>
        )}

        {/* Meta bar */}
        <div
          style={{
            fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
            fontSize: 13,
            color: 'var(--ca-text-secondary)',
            marginTop: 16,
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            flexWrap: 'wrap',
          }}
        >
          <span style={{ fontWeight: 500, color: 'var(--ca-text)' }}>Richard Yan</span>
          <a
            href="https://orcid.org/0009-0000-7611-6323"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: 'var(--ca-accent)', textDecoration: 'none', borderBottom: '1px solid transparent', transition: 'border-color 200ms', cursor: 'pointer', display: 'inline-flex', alignItems: 'center' }}
          >
            <img alt="ORCID" src="https://img.shields.io/badge/ORCID-0009--0000--7611--6323-green?logo=orcid" style={{ height: 16 }} />
          </a>
          <span>{chapter.date}</span>
        </div>

        <div style={{ height: 1, backgroundColor: 'var(--ca-border)', marginTop: 16 }} />

        {/* Tags */}
        {chapter.tags.length > 0 && (
          <div style={{ display: 'flex', gap: 6, marginTop: 12, flexWrap: 'wrap' }}>
            {chapter.tags.map((tag) => (
              <span
                key={tag}
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 11,
                  backgroundColor: 'var(--ca-hover-bg)',
                  color: 'var(--ca-accent)',
                  padding: '2px 8px',
                  borderRadius: 10,
                }}
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Markdown content */}
        <div
          style={{
            marginTop: 32,
            fontFamily: "'Source Serif 4', Georgia, serif",
            fontSize: 17,
            lineHeight: 1.75,
            color: 'var(--ca-text)',
          }}
          className="markdown-body"
        >
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              h2: ({ children }) => {
                const text = typeof children === 'string' ? children : Array.isArray(children) ? children.join('') : '';
                return (
                  <h2
                    id={slugify(text)}
                    style={{
                      fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
                      fontSize: 28,
                      fontWeight: 400,
                      color: 'var(--ca-text)',
                      marginTop: 48,
                      marginBottom: 16,
                      lineHeight: 1.35,
                      borderBottom: '1px solid #e5e0d6',
                      paddingBottom: 8,
                    }}
                  >
                    {children}
                  </h2>
                );
              },
              h3: ({ children }) => {
                const text = typeof children === 'string' ? children : Array.isArray(children) ? children.join('') : '';
                return (
                  <h3
                    id={slugify(text)}
                    style={{
                      fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
                      fontSize: 22,
                      fontWeight: 500,
                      color: 'var(--ca-text)',
                      marginTop: 32,
                      marginBottom: 12,
                      lineHeight: 1.4,
                    }}
                  >
                    {children}
                  </h3>
                );
              },
              h4: ({ children }) => {
                const text = typeof children === 'string' ? children : Array.isArray(children) ? children.join('') : '';
                return (
                  <h4
                    id={slugify(text)}
                    style={{
                      fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
                      fontSize: 18,
                      fontWeight: 600,
                      fontStyle: 'italic',
                      color: 'var(--ca-accent)',
                      marginTop: 24,
                      marginBottom: 10,
                    }}
                  >
                    {children}
                  </h4>
                );
              },
              p: ({ children }) => (
                <p
                  style={{
                    marginBottom: '1.2em',
                    textAlign: 'justify' as const,
                  }}
                >
                  {children}
                </p>
              ),
              blockquote: ({ children }) => (
                <blockquote
                  style={{
                    borderLeft: '3px solid #b8860b',
                    padding: '16px 20px',
                    margin: '24px 0',
                    backgroundColor: 'var(--ca-code-bg)',
                    borderRadius: '0 4px 4px 0',
                    fontStyle: 'italic',
                    color: 'var(--ca-text-secondary)',
                  }}
                >
                  {children}
                </blockquote>
              ),
              a: ({ href, children, id }) => {
                const isInternal = href && href.startsWith('/') && !href.startsWith('//');
                const fixedHref = isInternal ? '/#' + href : href;
                // fnref- = footnote return link (↩), fn- = footnote reference in text ([^1])
                const isFootnoteReturn = href && href.startsWith('#user-content-fnref');
                const isFootnoteRef = href && href.startsWith('#user-content-fn-');
                
                const handleClick = () => {
                  if (isInternal) {
                    navigate(href);
                  } else if (isFootnoteReturn || isFootnoteRef) {
                    const targetId = href.replace('#', '');
                    const el = document.getElementById(targetId);
                    if (el) {
                      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                  }
                };
                
                // Footnote return links (↩) use <button> to avoid HashRouter anchor conflicts
                if (isFootnoteReturn) {
                  return (
                    <button
                      onClick={handleClick}
                      style={{
                        color: 'var(--ca-accent)',
                        textDecoration: 'none',
                        border: 'none',
                        background: 'none',
                        cursor: 'pointer',
                        padding: 0,
                        font: 'inherit',
                        fontSize: 'inherit',
                      }}
                    >
                      {children}
                    </button>
                  );
                }
                
                return (
                  <a
                    id={id}
                    href={fixedHref}
                    onClick={(e) => { e.preventDefault(); handleClick(); }}
                    style={{
                      color: 'var(--ca-accent)',
                      textDecoration: 'none',
                      borderBottom: '1px solid transparent',
                      transition: 'border-color 200ms',
                      cursor: 'pointer',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderBottomColor = 'var(--ca-accent)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderBottomColor = 'transparent';
                    }}
                  >
                    {children}
                  </a>
                );
              },
              sup: ({ children }) => (
                <sup
                  style={{
                    fontSize: '0.75em',
                    verticalAlign: 'super',
                    lineHeight: 0,
                  }}
                >
                  {children}
                </sup>
              ),
              code: ({ children }) => (
                <code
                  style={{
                    backgroundColor: 'var(--ca-hover-bg)',
                    padding: '2px 6px',
                    borderRadius: 3,
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: '0.88em',
                    color: 'var(--ca-accent)',
                  }}
                >
                  {children}
                </code>
              ),
              pre: ({ children }) => (
                <pre
                  style={{
                    backgroundColor: 'var(--ca-code-bg)',
                    padding: 16,
                    borderRadius: 6,
                    border: '1px solid #e5e0d6',
                    overflowX: 'auto' as const,
                    margin: '1em 0',
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: 14,
                  }}
                >
                  {children}
                </pre>
              ),
              table: ({ children }) => (
                <table
                  style={{
                    width: '100%',
                    borderCollapse: 'collapse',
                    margin: '1.5em 0',
                    fontSize: '0.92em',
                    lineHeight: 1.5,
                    userSelect: 'none',
                  }}
                >
                  {children}
                </table>
              ),
              thead: ({ children }) => (
                <thead style={{ backgroundColor: 'var(--ca-text)', color: 'var(--ca-bg)' }}>
                  {children}
                </thead>
              ),
              th: ({ children }) => (
                <th
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontWeight: 600,
                    padding: '12px 14px',
                    textAlign: 'left',
                    border: 'none',
                  }}
                >
                  {children}
                </th>
              ),
              td: ({ children }) => (
                <td
                  style={{
                    padding: '10px 14px',
                    borderBottom: '1px solid #e5e0d6',
                    verticalAlign: 'top',
                  }}
                >
                  {children}
                </td>
              ),
              tr: ({ children }) => <tr>{children}</tr>,
              hr: () => (
                <hr
                  style={{
                    border: 'none',
                    borderTop: '1px solid #e5e0d6',
                    margin: '2em 0',
                  }}
                />
              ),
              ul: ({ children }) => (
                <ul style={{ marginBottom: '1.2em', paddingLeft: '2em' }}>{children}</ul>
              ),
              ol: ({ children }) => (
                <ol style={{
                  marginBottom: '1.2em',
                  paddingLeft: '2.5em',
                  listStyleType: 'decimal',
                  counterReset: 'none',
                }}>{children}</ol>
              ),
              li: ({ children, id }) => (
                <li
                  id={id}
                  style={{
                    marginBottom: '0.8em',
                    color: 'var(--ca-text-secondary)',
                    lineHeight: 1.6,
                    display: 'list-item',
                  }}
                >
                  {children}
                </li>
              ),
              strong: ({ children }) => (
                <strong style={{ fontWeight: 600 }}>{children}</strong>
              ),
              em: ({ children }) => (
                <em style={{ fontStyle: 'italic' }}>{children}</em>
              ),
              img: ({ src, alt }) => {
                const resolved = src?.startsWith('http') ? src : getImageUrl(chapter.file, src || '');
                return (
                  <img
                    src={resolved || src}
                    alt={alt}
                    style={{ maxWidth: '100%', height: 'auto', display: 'block', margin: '1em auto', borderRadius: 4 }}
                  />
                );
              },
              // Footnotes section at bottom - just style the container, let gfm handle the title
              section: ({ children, ...props }) => {
                const isFootnotes = props['data-footnotes' as keyof typeof props];
                if (isFootnotes) {
                  return (
                    <section
                      data-footnotes
                      style={{
                        borderTop: '1px solid #e5e0d6',
                        marginTop: '3em',
                        paddingTop: '1.5em',
                      }}
                    >
                      {children}
                    </section>
                  );
                }
                return <section {...props}>{children}</section>;
              },
            }}
          >
            {getContent(chapter.file).replace(/^#\s+[^\n]+\n+/, '')}
          </ReactMarkdown>
        </div>

        {/* Navigation footer */}
        <div
          style={{
            marginTop: 64,
            paddingTop: 24,
            borderTop: '1px solid #e5e0d6',
            display: 'flex',
            justifyContent: 'space-between',
            fontFamily: "'Inter', sans-serif",
            fontSize: 13,
          }}
        >
          {getPrevNext(location.pathname).prev && (
            <a
              href={`#${getPrevNext(location.pathname).prev?.path}`}
              onClick={(e) => {
                e.preventDefault();
                navigate(getPrevNext(location.pathname).prev?.path || '/');
              }}
              style={{ color: 'var(--ca-accent)', textDecoration: 'none' }}
            >
              &larr; {getPrevNext(location.pathname).prev?.label}
            </a>
          )}
          <span />
          {getPrevNext(location.pathname).next && (
            <a
              href={`#${getPrevNext(location.pathname).next?.path}`}
              onClick={(e) => {
                e.preventDefault();
                navigate(getPrevNext(location.pathname).next?.path || '/');
              }}
              style={{ color: 'var(--ca-accent)', textDecoration: 'none' }}
            >
              {getPrevNext(location.pathname).next?.label} &rarr;
            </a>
          )}
        </div>

      </div>

      {/* Footer when right panel is hidden — full width, outside content container */}
      {showFooter && (
        <div style={{ padding: isMobile ? '12px 16px 20px' : '16px 32px 20px', textAlign: 'right', flexShrink: 0 }}>
          <div style={{ display: 'flex', gap: 12, marginBottom: 6, justifyContent: 'flex-end' }}>
            <a href="mailto:partners@codeafter.ai" title="Email" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><Mail size={14} /></a>
            <a href="https://codeafter.ai" target="_blank" rel="noopener noreferrer" title="Website" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><Globe size={14} /></a>
            <a href="https://codeafter.substack.com" target="_blank" rel="noopener noreferrer" title="Substack" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><BookOpen size={14} /></a>
            <a href="https://www.linkedin.com/company/codeafter-ai" target="_blank" rel="noopener noreferrer" title="LinkedIn" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><Linkedin size={14} /></a>
            <a href="https://zenodo.org/communities/code-after" target="_blank" rel="noopener noreferrer" title="Zenodo" style={{ color: 'var(--ca-text-secondary)' }} onMouseEnter={e => e.currentTarget.style.color = 'var(--ca-accent)'} onMouseLeave={e => e.currentTarget.style.color = 'var(--ca-text-secondary)'}><Archive size={14} /></a>
          </div>
          <div style={{ fontSize: 11, color: 'var(--ca-text-secondary)', lineHeight: 1.6 }}>
            <div>&copy; Richard Yan · <a href="#/contact" style={{ color: 'var(--ca-text-secondary)', textDecoration: 'underline' }}>Contact</a> · <a href="#/faq" style={{ color: 'var(--ca-text-secondary)', textDecoration: 'underline' }}>FAQ</a></div>
            <div>Content licensed under CC BY-NC-ND 4.0</div>
          </div>
        </div>
      )}

    </div>
    </>
  );
}

/** Navigation derived from documentTree — zero hardcoding */
const pageOrder = flattenTree(documentTree);

function getPrevNext(path: string) {
  const idx = pageOrder.findIndex((p) => p.path === path);
  return {
    prev: idx > 0 ? pageOrder[idx - 1] : null,
    next: idx < pageOrder.length - 1 ? pageOrder[idx + 1] : null,
  };
}
