import { Menu, Moon, Sun } from 'lucide-react';

interface TopBarProps {
  sidebarOpen: boolean;
  onToggleSidebar: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function TopBar({ onToggleSidebar, darkMode, onToggleDarkMode }: TopBarProps) {
  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        height: 48,
        backgroundColor: 'var(--ca-bg)',
        borderBottom: '1px solid var(--ca-border)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 16px',
        zIndex: 100,
      }}
    >
      {/* Logo */}
      <div>
        <div
          style={{
            fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
            fontSize: 16,
            fontWeight: 600,
            color: 'var(--ca-accent)',
            letterSpacing: 0.3,
          }}
        >
          Code After
        </div>
        <div
          style={{
            fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
            fontSize: 10,
            color: 'var(--ca-text-secondary)',
            lineHeight: 1.2,
          }}
        >
          A Knowledge Lab for AI Governance
        </div>
      </div>

      {/* Right side: theme toggle + hamburger */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
        <button
          onClick={onToggleDarkMode}
          title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: 6,
            borderRadius: 4,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--ca-icon)',
            transition: 'color 200ms, background 200ms',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--ca-text)';
            e.currentTarget.style.backgroundColor = 'var(--ca-hover-bg)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--ca-icon)';
            e.currentTarget.style.backgroundColor = 'transparent';
          }}
        >
          {darkMode ? <Sun size={18} /> : <Moon size={18} />}
        </button>

        <button
          onClick={onToggleSidebar}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: 6,
            borderRadius: 4,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--ca-icon)',
            transition: 'color 200ms, background 200ms',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--ca-text)';
            e.currentTarget.style.backgroundColor = 'var(--ca-hover-bg)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--ca-icon)';
            e.currentTarget.style.backgroundColor = 'transparent';
          }}
        >
          <Menu size={20} />
        </button>
      </div>
    </header>
  );
}
