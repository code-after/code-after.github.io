import { Moon, Sun } from 'lucide-react';

interface ThemeToggleProps {
  darkMode: boolean;
  onToggle: () => void;
}

export default function ThemeToggle({ darkMode, onToggle }: ThemeToggleProps) {
  return (
    <button
      onClick={onToggle}
      title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
      style={{
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: 6,
        borderRadius: 4,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--ca-icon)',
        transition: 'color 200ms, background 200ms',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.color = 'var(--ca-text)';
        e.currentTarget.style.backgroundColor = 'var(--ca-hover-bg)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.color = 'var(--ca-icon)';
        e.currentTarget.style.backgroundColor = 'transparent';
      }}
    >
      {darkMode ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}
